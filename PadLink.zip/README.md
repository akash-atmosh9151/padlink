# PadLink 🎮
Phone touch-controller for Asphalt on Mac.

- `android/` – the app (APK is built automatically by GitHub Actions)
- `mac/` – the Mac helper that presses the real keys

## Get the APK
Push to `main` → **Actions** tab → wait for the green tick → open **Releases → PadLink APK (latest)** on your phone and install `PadLink.apk`.

## Mac setup
```bash
cd mac && npm install && npm run build && npm start
```
Allow Terminal in System Settings → Privacy & Security → Accessibility.
Open the app, enter the Mac address + PIN printed in the terminal (same Wi-Fi).
