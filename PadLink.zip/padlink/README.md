# PadLink

Use your Android phone as a trackpad and game controller for a Mac, a Windows PC, or another Android device.

Two ways to connect:

| | Bluetooth | Wi-Fi |
|---|---|---|
| Software on the computer | none | `host/padlink_host.py` |
| Works with | Mac, Windows, Android, Chromebook, Linux, iPad, TVs | Mac, Windows |
| Latency | good (Bluetooth link, ~125 Hz max) | best (UDP, up to 1000 Hz) |
| Extras | mouse, keys | mouse, keys, smooth scroll, ping/latency, PC-triggered haptics |

## 1. Get the APK (build on GitHub, no computer needed)

1. Create a new GitHub repository (for example `padlink`) and upload everything in this folder, including the hidden `.github` folder.
2. Open the repo's **Actions** tab, pick **Build APK**, and press **Run workflow** (it also runs on every push).
3. When it finishes, open the run and download the **PadLink-debug-apk** artifact. Unzip it and install `app-debug.apk` on the phone (allow "install unknown apps" for your browser or files app).

Local build, if you have Android Studio or the SDK: `gradle :app:assembleDebug` (Gradle 8.9+, JDK 17).

## 2a. Bluetooth mode (any computer, no software)

1. PadLink > **Bluetooth** > **Make discoverable**.
2. Tap **Start** in PadLink and leave the pad screen open (the phone only advertises its HID service while it is open).
3. On the computer, open Bluetooth settings and pair with the phone. If it was paired before, forget it on both sides first. You can also select the computer in the "Paired computers" list so the phone connects by itself.

Notes: the phone must have Bluetooth on and Android 9 or newer. If registration fails, another app may be holding the Bluetooth HID profile.

## 2b. Wi-Fi mode (Mac / Windows)

Phone and computer must be on the same Wi-Fi network.

**macOS**: `python3 host/padlink_host.py`. The first run needs Accessibility permission: System Settings > Privacy & Security > Accessibility > enable your Terminal app, then run it again.

**Windows**: `py host/padlink_host.py`. Allow Python through the firewall on private networks when asked. To control a game that runs as administrator, start the script from an administrator terminal too.

The receiver prints a PIN and its IP address. In PadLink choose **Wi-Fi**, tap **Scan network** (or type the IP), enter the PIN and press **Start**.

Receiver options: `--pin 1234`, `--no-pin`, `--port N`, `--no-keys`, `--scroll-scale X`, `--flip-hscroll`, `--dry-run` (prints instead of moving the mouse). Type `buzz` in its console to test haptics.

## Using the pad

| Gesture | Action |
|---|---|
| one finger | move pointer (with speed-based acceleration) |
| tap | left click |
| tap, then touch again and hold | drag |
| two fingers | scroll (natural or classic) |
| two-finger tap | right click |
| three-finger tap | middle click |

The play screen has three zones: a floating **stick** on one side that presses W/A/S/D, the **trackpad** in the middle, and **buttons** on the other side (configurable keys plus big LMB/RMB). Layouts: trackpad only, trackpad + buttons, or all three. "Swap sides" mirrors it for left-handed play. Press back twice to disconnect.

## Haptics

Settings > Haptics. Modes: **Crisp** (the phone's tuned vibration primitives, falls back automatically), **System** (lowest latency), **Custom** (your own pulse length and strength), **Off**. Strength, and separate toggles for clicks, scroll ticks, drag, key presses and connect/disconnect. Test buttons are on the same screen. In Wi-Fi mode the PC can make the phone buzz: type `buzz` in the receiver, or send the UDP text `HAP <ms> <strength>` to `127.0.0.1:48916` from any script or game mod.

## Developer options

Settings > Developer:

- send rate (every touch event, 125, 250, 500, 1000 Hz)
- artificial lag (0-200 ms) for testing how a game feels with latency
- HUD: link state, round-trip time, packets per second, haptics hardware
- touch overlay with coordinates, and a live packet log
- tap duration / movement / drag window / click hold time, pointer dead zone
- gyro aiming: off, while holding a GYRO button, or always (with sensitivity and axis inversion)
- volume keys as left/right click, keep screen on, immersive mode
- custom button list (`shift,space,ctrl,~ctrl,lmb,rmb,f5,...`; a leading `~` latches the button) and custom stick keys
- reset all settings

## Protocol (Wi-Fi)

One UDP datagram per message, UTF-8, space separated.

```
phone -> PC   HELLO <pin|-> <name>            -> OK <token> <os> <host>  |  NO <reason>
              <token> M dx dy                  relative motion
              <token> S sx sy                  scroll, 120 = one notch, +y up, +x right
              <token> B <0..4> <0|1>           buttons: left right middle back forward
              <token> K <name> <0|1>           key down/up (names in HidKeys.kt)
              <token> PING <ms> | REL | BYE
PC -> phone   PONG <ms> | HAP <ms> <strength> | BYE
discovery     "PADLINK?" broadcast -> "PADLINK! <port> <os> <host>"
```

The token is issued after the PIN check; packets without it are ignored. The receiver releases every held key and button if the phone goes quiet for 3 seconds.

## Known limits

- Some games read the mouse through raw input and ignore synthetic input, and anti-cheat software may block it. Single-player and most indie games are fine.
- On Windows, "Enhance pointer precision" adds its own acceleration on top of PadLink's; turn it off for predictable aim.
- Bluetooth scroll is in whole wheel notches (no smooth scroll), and Bluetooth motion is capped by the link's report rate.
- Android as the *computer* is supported through Bluetooth mode only. It sees PadLink as an ordinary mouse and keyboard.


## Gamepad layout

The default layout is a classic controller: left stick, d-pad, A/B/X/Y, right stick, LB/RB/LT/RT, Back/Start.

- **Bluetooth + "Real Bluetooth gamepad"** (default): the phone registers as a HID game pad (16 buttons, hat, 6 axes).
  On a Mac, open Steam > Settings > Controller and enable generic gamepad support, then set the layout up once.
- **Wi-Fi, or Bluetooth + "Keyboard + mouse keys"**: the controller is turned into keys. Left stick = stick keys (WASD),
  d-pad = arrows, right stick = mouse look, buttons = Settings > Gamepad keys (A,B,X,Y,LB,RB,LT,RT,Back,Start).
