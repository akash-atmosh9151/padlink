package app.padlink

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.view.MotionEvent
import android.view.View
import kotlin.math.abs

/**
 * Floating 8-way stick that presses keys (default W/A/S/D) instead of moving the pointer.
 * The stick appears wherever the thumb lands, so there is nothing to aim for.
 */
class StickView(
    ctx: Context,
    private val cfg: Cfg,
    private val tr: Transport,
    private val hap: Haptics
) : View(ctx) {

    private val density = ctx.resources.displayMetrics.density
    private val keys = cfg.stickKeys              // up, left, down, right
    private val held = BooleanArray(4)

    private var pid = -1
    private var ox = 0f
    private var oy = 0f
    private var kx = 0f
    private var ky = 0f

    private val radius = 56f * density
    private val dead = 14f * density

    private val ring = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = 2f * density; color = Ui.LINE }
    private val knob = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL; color = 0x55FFFFFF }
    private val edge = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = 2f * density; color = Ui.LINE }
    private val label = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Ui.DIM; typeface = Ui.MONO; textSize = 12f * density; textAlign = Paint.Align.CENTER; letterSpacing = 0.25f
    }

    init { setBackgroundColor(Ui.BG) }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN, MotionEvent.ACTION_POINTER_DOWN -> if (pid == -1) {
                val i = e.actionIndex
                requestUnbufferedDispatch(e)
                pid = e.getPointerId(i)
                ox = e.getX(i); oy = e.getY(i)
                kx = ox; ky = oy
            }
            MotionEvent.ACTION_MOVE -> {
                val i = e.findPointerIndex(pid)
                if (i >= 0) {
                    kx = e.getX(i); ky = e.getY(i)
                    // drag the origin along if the thumb wanders far, so reversing direction stays quick
                    val dx = kx - ox
                    val dy = ky - oy
                    val d = Math.hypot(dx.toDouble(), dy.toDouble()).toFloat()
                    if (d > radius * 1.6f) {
                        val k = (d - radius * 1.6f) / d
                        ox += dx * k; oy += dy * k
                    }
                    update(kx - ox, ky - oy)
                }
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_POINTER_UP, MotionEvent.ACTION_CANCEL -> {
                if (e.actionMasked == MotionEvent.ACTION_CANCEL || e.getPointerId(e.actionIndex) == pid) {
                    pid = -1
                    update(0f, 0f)
                }
            }
        }
        invalidate()
        return true
    }

    private fun update(dx: Float, dy: Float) {
        val ax = abs(dx)
        val ay = abs(dy)
        val active = pid != -1
        // 8-way: an axis counts unless the thumb is within ~22 degrees of the other axis
        val up = active && dy < -dead && ax < ay * 2.5f
        val down = active && dy > dead && ax < ay * 2.5f
        val left = active && dx < -dead && ay < ax * 2.5f
        val right = active && dx > dead && ay < ax * 2.5f
        set(0, up)
        set(1, left)
        set(2, down)
        set(3, right)
    }

    private fun set(i: Int, on: Boolean) {
        if (held[i] == on) return
        held[i] = on
        tr.key(keys[i], on)
        if (on) hap.fire(Hap.KEY)
    }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        val r = 22f * density
        c.drawRoundRect(2f * density, 2f * density, w - 2f * density, h - 2f * density, r, r, edge)
        if (pid == -1) {
            c.drawText("MOVE", w / 2f, h / 2f, label)
            return
        }
        c.drawCircle(ox, oy, radius, ring)
        val dx = kx - ox
        val dy = ky - oy
        val d = Math.hypot(dx.toDouble(), dy.toDouble()).toFloat()
        val k = if (d > radius) radius / d else 1f
        c.drawCircle(ox + dx * k, oy + dy * k, 26f * density, knob)
    }
}
