package app.padlink

/**
 * Canonical key names used everywhere (button layout, UDP protocol, Bluetooth HID).
 * The desktop receiver understands exactly the same names.
 */
object HidKeys {
    /** name -> HID keyboard usage id (usage page 0x07) */
    val usage: Map<String, Int>

    /** name -> modifier bit in the HID keyboard report */
    val modifier: Map<String, Int> = mapOf(
        "ctrl" to 0x01, "shift" to 0x02, "alt" to 0x04, "cmd" to 0x08, "win" to 0x08, "gui" to 0x08
    )

    init {
        val m = HashMap<String, Int>()
        for (i in 0 until 26) m[('a' + i).toString()] = 4 + i
        for (i in 1..9) m[i.toString()] = 29 + i
        m["0"] = 39
        m["enter"] = 40; m["esc"] = 41; m["backspace"] = 42; m["tab"] = 43; m["space"] = 44
        m["minus"] = 45; m["equals"] = 46; m["lbracket"] = 47; m["rbracket"] = 48; m["backslash"] = 49
        m["semicolon"] = 51; m["quote"] = 52; m["grave"] = 53; m["comma"] = 54; m["period"] = 55; m["slash"] = 56
        m["caps"] = 57
        for (i in 1..12) m["f$i"] = 57 + i
        m["insert"] = 73; m["home"] = 74; m["pgup"] = 75; m["delete"] = 76; m["end"] = 77; m["pgdn"] = 78
        m["right"] = 79; m["left"] = 80; m["down"] = 81; m["up"] = 82
        usage = m
    }

    fun isKnown(name: String) = usage.containsKey(name) || modifier.containsKey(name)

    /** Short label for on-screen buttons. */
    fun label(name: String): String = when (name) {
        "space" -> "SPACE"
        "backspace" -> "BKSP"
        "escape" -> "ESC"
        "ctrl" -> "CTRL"
        "shift" -> "SHIFT"
        "alt" -> "ALT"
        "cmd", "win", "gui" -> "CMD"
        "enter" -> "ENTER"
        else -> name.uppercase()
    }
}
