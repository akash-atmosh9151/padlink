package app.padlink

import android.content.Context
import android.content.SharedPreferences

/** Thin wrapper over SharedPreferences. Sliders always store floats. */
object Prefs {
    private var sp: SharedPreferences? = null

    fun init(c: Context) {
        if (sp == null) sp = c.applicationContext.getSharedPreferences("padlink", Context.MODE_PRIVATE)
    }

    private fun p(): SharedPreferences = sp!!

    fun str(k: String, d: String): String = p().getString(k, d) ?: d
    fun bool(k: String, d: Boolean): Boolean = p().getBoolean(k, d)
    fun flt(k: String, d: Float): Float = p().getFloat(k, d)

    fun putStr(k: String, v: String) = p().edit().putString(k, v).apply()
    fun putBool(k: String, v: Boolean) = p().edit().putBoolean(k, v).apply()
    fun putFlt(k: String, v: Float) = p().edit().putFloat(k, v).apply()
    fun clearAll() = p().edit().clear().apply()
}

/** Immutable snapshot of every setting, read once when the pad screen opens (keeps the touch path allocation-free). */
class Cfg {
    // connection
    val mode = Prefs.str("mode", "wifi")                 // wifi | bt
    val ip = Prefs.str("ip", "")
    val port = Prefs.str("port", "48915").toIntOrNull() ?: 48915
    val pin = Prefs.str("pin", "")

    // pointer
    val sens = Prefs.flt("sens", 1.6f)
    val accel = Prefs.flt("accel", 0.6f)
    val deadzone = Prefs.flt("deadzone", 0f)
    val invertX = Prefs.bool("invert_x", false)
    val invertY = Prefs.bool("invert_y", false)

    // gestures
    val tapClick = Prefs.bool("tap_click", true)
    val tapDrag = Prefs.bool("tap_drag", true)
    val twoTapRight = Prefs.bool("two_tap_right", true)
    val threeTapMiddle = Prefs.bool("three_tap_middle", true)
    val scrollSpeed = Prefs.flt("scroll_speed", 1.0f)
    val naturalScroll = Prefs.bool("natural_scroll", true)
    val tapMs = Prefs.flt("tap_ms", 200f).toInt()
    val tapSlopDp = Prefs.flt("tap_slop", 10f)
    val dragWindowMs = Prefs.flt("drag_window", 280f).toInt()
    val clickHoldMs = Prefs.flt("click_hold", 25f).toInt()   // how long a tap-click keeps the button down
    val volKeys = Prefs.bool("vol_keys", false)              // volume up/down act as left/right click

    // layout
    val layout = Prefs.str("layout", "game")             // pad | buttons | game
    val keys: List<String> = Prefs.str("keys", "shift,space,ctrl,r,e,q")
        .split(',').map { it.trim().lowercase() }.filter { it.isNotEmpty() }
    val fireButtons = Prefs.bool("fire_buttons", true)
    val swapSides = Prefs.bool("swap_sides", false)
    /** up,left,down,right key names for the on-screen stick */
    val stickKeys: List<String> = Prefs.str("stick_keys", "w,a,s,d")
        .split(',').map { it.trim().lowercase() }.filter { it.isNotEmpty() }
        .let { if (it.size == 4 && it.all { k -> HidKeys.isKnown(k) }) it else listOf("w", "a", "s", "d") }

    // haptics
    val hapMode = Prefs.str("hap_mode", "crisp")         // off | system | crisp | custom
    val hapStrength = Prefs.flt("hap_strength", 200f).toInt()
    val hapMs = Prefs.flt("hap_ms", 18f).toInt()
    val hapClick = Prefs.bool("hap_click", true)
    val hapScroll = Prefs.bool("hap_scroll", true)
    val hapDrag = Prefs.bool("hap_drag", true)
    val hapKeys = Prefs.bool("hap_keys", true)
    val hapConn = Prefs.bool("hap_conn", true)
    val hapScrollPx = Prefs.flt("hap_scroll_px", 48f)
    val hapHost = Prefs.bool("hap_host", true)           // allow the PC to trigger haptics

    // developer
    val pollHz = Prefs.str("poll_hz", "250").toIntOrNull() ?: 250   // 0 = send every touch event
    val fakeLag = Prefs.flt("fake_lag", 0f).toInt()      // artificial delay (ms) for testing
    val hud = Prefs.bool("hud", false)
    val touches = Prefs.bool("touches", false)
    val logPackets = Prefs.bool("log_packets", false)
    val keepAwake = Prefs.bool("keep_awake", true)
    val immersive = Prefs.bool("immersive", true)
    val gyroMode = Prefs.str("gyro_mode", "off")         // off | hold | always
    val gyroSens = Prefs.flt("gyro_sens", 1.0f)
    val gyroInvX = Prefs.bool("gyro_inv_x", false)
    val gyroInvY = Prefs.bool("gyro_inv_y", false)
}
