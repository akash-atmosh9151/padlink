package app.padlink

import android.Manifest
import android.app.Activity
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Toast

/** Connect screen: pick Wi-Fi receiver or Bluetooth HID, then start. */
class MainActivity : Activity() {

    private lateinit var content: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Prefs.init(this)
        val scroll = ScrollView(this)
        scroll.setBackgroundColor(Color.BLACK)
        Ui.fitSystemBars(scroll)
        content = LinearLayout(this)
        content.orientation = LinearLayout.VERTICAL
        scroll.addView(content)
        setContentView(scroll)
    }

    override fun onResume() {
        super.onResume()
        render()
    }

    private fun margins(): LinearLayout.LayoutParams =
        Ui.lp().apply {
            val m = Ui.dpi(this@MainActivity, 18)
            setMargins(m, Ui.dpi(this@MainActivity, 8), m, 0)
        }

    private fun render() {
        content.removeAllViews()
        val f = Form(this, content)
        val pad = Ui.dpi(this, 18)

        content.addView(Ui.text(this, "PADLINK", 32f, Color.WHITE, true).apply {
            letterSpacing = 0.2f
            setPadding(pad, Ui.dpi(this@MainActivity, 36), pad, 0)
        })
        content.addView(Ui.text(this, "phone as trackpad + game controller", 12f, Ui.DIM, true).apply {
            setPadding(pad, 0, pad, 0)
        })

        f.section("Connection")
        val mode = Prefs.str("mode", "wifi")
        val modes = LinearLayout(this)
        modes.orientation = LinearLayout.HORIZONTAL
        modes.setPadding(pad, 0, pad, 0)
        fun modeButton(label: String, value: String, side: Int) {
            val b = Ui.button(this, label, mode == value) { Prefs.putStr("mode", value); render() }
            val p = Ui.lp(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            if (side == 0) p.rightMargin = Ui.dpi(this, 4) else p.leftMargin = Ui.dpi(this, 4)
            modes.addView(b, p)
        }
        modeButton("Wi-Fi", "wifi", 0)
        modeButton("Bluetooth", "bt", 1)
        content.addView(modes)

        if (mode == "wifi") wifiSection(f) else bluetoothSection(f)

        content.addView(Ui.button(this, "Start", true) { start() }, margins().apply { topMargin = Ui.dpi(this@MainActivity, 28) })
        content.addView(Ui.button(this, "Settings + developer options") {
            startActivity(Intent(this, SettingsActivity::class.java))
        }, margins())
        content.addView(View(this), Ui.lp(ViewGroup.LayoutParams.MATCH_PARENT, Ui.dpi(this, 40)))
    }

    // ------------------------------------------------------------------ Wi-Fi

    private fun wifiSection(f: Form) {
        f.info(
            "Lowest latency, plus extras. Run padlink_host.py on the Mac or PC (same Wi-Fi), " +
                "then scan, or type the IP address it prints."
        )
        val found = LinearLayout(this)
        found.orientation = LinearLayout.VERTICAL
        content.addView(Ui.button(this, "Scan network") { scan(found) }, margins())
        content.addView(found, margins())
        f.text("Receiver IP", "ip", "", "192.168.1.20")
        f.text("Port", "port", "48915", "48915", numeric = true)
        f.text("PIN", "pin", "", "shown by the receiver", numeric = true)
    }

    private fun scan(list: LinearLayout) {
        list.removeAllViews()
        list.addView(Ui.text(this, "Scanning...", 12f, Ui.DIM, true))
        val port = Prefs.str("port", "48915").toIntOrNull() ?: 48915
        var any = false
        Discovery.scan(port, 3000) { r ->
            runOnUiThread {
                if (!any) { any = true; list.removeAllViews() }
                list.addView(Ui.button(this, "${r.name}  ${r.os}  ${r.ip}") {
                    Prefs.putStr("ip", r.ip)
                    Prefs.putStr("port", r.port.toString())
                    render()
                }, Ui.lp().apply { topMargin = Ui.dpi(this@MainActivity, 6) })
            }
        }
        list.postDelayed({
            if (!any) {
                list.removeAllViews()
                list.addView(Ui.text(this, "Nothing found. Check the receiver is running, then type its IP below.", 12f, Ui.WARN, true))
            }
        }, 3400)
    }

    // ------------------------------------------------------------------ Bluetooth

    private fun btPermitted(): Boolean =
        Build.VERSION.SDK_INT < 31 ||
            (checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED)

    private fun requestBt() {
        requestPermissions(arrayOf(Manifest.permission.BLUETOOTH_CONNECT, Manifest.permission.BLUETOOTH_ADVERTISE), 7)
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 7) {
            if (btPermitted()) render()
            else Toast.makeText(this, "Bluetooth permission is needed for this mode", Toast.LENGTH_LONG).show()
        }
    }

    @android.annotation.SuppressLint("MissingPermission")
    private fun bluetoothSection(f: Form) {
        f.info(
            "No software needed on the computer: the phone appears as a Bluetooth mouse + keyboard " +
                "to a Mac, a Windows PC, another Android, a Chromebook, a TV...\n\n" +
                "1. Tap Make discoverable.\n" +
                "2. On the computer, open Bluetooth settings and pair with this phone.\n" +
                "3. Tap Start. Connect from the computer, or pick it below to connect from the phone."
        )
        if (!btPermitted()) {
            content.addView(Ui.button(this, "Allow Bluetooth") { requestBt() }, margins())
            return
        }
        content.addView(Ui.button(this, "Make discoverable") {
            startActivity(
                Intent(BluetoothAdapter.ACTION_REQUEST_DISCOVERABLE)
                    .putExtra(BluetoothAdapter.EXTRA_DISCOVERABLE_DURATION, 300)
            )
        }, margins())

        f.section("Paired computers")
        val adapter = (getSystemService(Context.BLUETOOTH_SERVICE) as? BluetoothManager)?.adapter
        if (adapter == null || !adapter.isEnabled) {
            f.info("Bluetooth is off. Turn it on, then come back.")
            return
        }
        val chosen = Prefs.str("bt_addr", "")
        val bonded = adapter.bondedDevices.toList()
        if (bonded.isEmpty()) f.info("Nothing paired yet.")
        for (d in bonded) {
            val selected = d.address == chosen
            content.addView(Ui.button(this, (if (selected) "* " else "") + (d.name ?: d.address), selected) {
                Prefs.putStr("bt_addr", if (selected) "" else d.address)
                render()
            }, margins())
        }
        f.info("Selecting one makes the phone connect to it automatically. Select none to wait for the computer to connect.")
    }

    // ------------------------------------------------------------------ start

    private fun start() {
        if (Prefs.str("mode", "wifi") == "wifi") {
            if (Prefs.str("ip", "").isEmpty()) {
                Toast.makeText(this, "Scan for the receiver or type its IP address", Toast.LENGTH_SHORT).show()
                return
            }
        } else if (!btPermitted()) {
            requestBt()
            return
        }
        startActivity(Intent(this, PadActivity::class.java))
    }
}
