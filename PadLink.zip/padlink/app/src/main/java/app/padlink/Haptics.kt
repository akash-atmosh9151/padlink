package app.padlink

import android.content.Context
import android.os.Build
import android.os.VibrationEffect
import android.os.VibrationEffect.Composition
import android.os.Vibrator
import android.os.VibratorManager
import android.view.HapticFeedbackConstants
import android.view.View

enum class Hap { CLICK_DOWN, CLICK_UP, RIGHT, TICK, DRAG, KEY, CONNECT, LOST }

@Suppress("DEPRECATION")
private fun getVibrator(ctx: Context): Vibrator =
    if (Build.VERSION.SDK_INT >= 31)
        (ctx.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as VibratorManager).defaultVibrator
    else
        ctx.getSystemService(Context.VIBRATOR_SERVICE) as Vibrator

/**
 * Haptics engine with four modes:
 *  off     - nothing
 *  system  - View.performHapticFeedback (lowest latency, uses the phone's own tuned effects)
 *  crisp   - VibrationEffect.Composition primitives (API 30+, falls back to predefined effects, then one-shots)
 *  custom  - raw one-shot pulses with your own duration + amplitude
 */
class Haptics(ctx: Context, private val cfg: Cfg) {
    private val vib: Vibrator = getVibrator(ctx)
    private val hasAmp: Boolean = vib.hasAmplitudeControl()
    private val primitives: Boolean = Build.VERSION.SDK_INT >= 30 &&
        vib.areAllPrimitivesSupported(
            Composition.PRIMITIVE_CLICK, Composition.PRIMITIVE_TICK,
            Composition.PRIMITIVE_LOW_TICK, Composition.PRIMITIVE_THUD
        )

    /** View used for "system" mode. */
    var anchor: View? = null

    fun describe(): String =
        "vibrator=${vib.hasVibrator()} amplitude=$hasAmp primitives=$primitives api=${Build.VERSION.SDK_INT}"

    private fun enabled(h: Hap): Boolean = when (h) {
        Hap.CLICK_DOWN, Hap.CLICK_UP, Hap.RIGHT -> cfg.hapClick
        Hap.TICK -> cfg.hapScroll
        Hap.DRAG -> cfg.hapDrag
        Hap.KEY -> cfg.hapKeys
        Hap.CONNECT, Hap.LOST -> cfg.hapConn
    }

    fun fire(h: Hap) {
        if (cfg.hapMode == "off" || !enabled(h)) return
        play(h)
    }

    /** Settings-screen test: ignores the per-event toggles but respects the mode. */
    fun test(h: Hap) {
        if (cfg.hapMode != "off") play(h)
    }

    private fun play(h: Hap) {
        when (cfg.hapMode) {
            "system" -> system(h)
            "custom" -> custom(h)
            else -> when {
                primitives -> crisp(h)
                Build.VERSION.SDK_INT >= 29 -> predefined(h)
                else -> custom(h)
            }
        }
    }

    /** Raw pulse, also used when the PC asks the phone to buzz. */
    fun pulse(ms: Int, amp: Int) {
        val a = if (hasAmp) amp.coerceIn(1, 255) else VibrationEffect.DEFAULT_AMPLITUDE
        vib.vibrate(VibrationEffect.createOneShot(ms.coerceIn(1, 500).toLong(), a))
    }

    fun cancel() = vib.cancel()

    @Suppress("DEPRECATION")
    private fun system(h: Hap) {
        val v = anchor
        if (v == null) { custom(h); return }
        val c = when (h) {
            Hap.CLICK_DOWN -> HapticFeedbackConstants.VIRTUAL_KEY
            Hap.CLICK_UP -> if (Build.VERSION.SDK_INT >= 27) HapticFeedbackConstants.KEYBOARD_RELEASE else HapticFeedbackConstants.KEYBOARD_TAP
            Hap.RIGHT -> HapticFeedbackConstants.CONTEXT_CLICK
            Hap.TICK -> HapticFeedbackConstants.CLOCK_TICK
            Hap.DRAG -> HapticFeedbackConstants.LONG_PRESS
            Hap.KEY -> HapticFeedbackConstants.KEYBOARD_TAP
            Hap.CONNECT -> if (Build.VERSION.SDK_INT >= 30) HapticFeedbackConstants.CONFIRM else HapticFeedbackConstants.LONG_PRESS
            Hap.LOST -> if (Build.VERSION.SDK_INT >= 30) HapticFeedbackConstants.REJECT else HapticFeedbackConstants.LONG_PRESS
        }
        v.performHapticFeedback(c, HapticFeedbackConstants.FLAG_IGNORE_GLOBAL_SETTING)
    }

    private fun crisp(h: Hap) {
        val s = (cfg.hapStrength / 255f).coerceIn(0.05f, 1f)
        val b = VibrationEffect.startComposition()
        when (h) {
            Hap.CLICK_DOWN -> b.addPrimitive(Composition.PRIMITIVE_CLICK, s)
            Hap.CLICK_UP -> b.addPrimitive(Composition.PRIMITIVE_LOW_TICK, s * 0.7f)
            Hap.RIGHT -> b.addPrimitive(Composition.PRIMITIVE_CLICK, s)
                .addPrimitive(Composition.PRIMITIVE_THUD, s * 0.8f, 40)
            Hap.TICK -> b.addPrimitive(Composition.PRIMITIVE_TICK, s * 0.6f)
            Hap.DRAG -> b.addPrimitive(Composition.PRIMITIVE_THUD, s)
            Hap.KEY -> b.addPrimitive(Composition.PRIMITIVE_CLICK, s * 0.8f)
            Hap.CONNECT -> b.addPrimitive(Composition.PRIMITIVE_CLICK, s)
                .addPrimitive(Composition.PRIMITIVE_CLICK, s, 90)
            Hap.LOST -> b.addPrimitive(Composition.PRIMITIVE_THUD, s)
                .addPrimitive(Composition.PRIMITIVE_THUD, s, 120)
        }
        vib.vibrate(b.compose())
    }

    private fun predefined(h: Hap) {
        val e = when (h) {
            Hap.CLICK_DOWN, Hap.KEY -> VibrationEffect.EFFECT_CLICK
            Hap.CLICK_UP, Hap.TICK -> VibrationEffect.EFFECT_TICK
            Hap.RIGHT, Hap.DRAG -> VibrationEffect.EFFECT_HEAVY_CLICK
            Hap.CONNECT, Hap.LOST -> VibrationEffect.EFFECT_DOUBLE_CLICK
        }
        vib.vibrate(VibrationEffect.createPredefined(e))
    }

    private fun custom(h: Hap) {
        val ms = cfg.hapMs
        val a = cfg.hapStrength
        when (h) {
            Hap.CLICK_DOWN, Hap.KEY -> pulse(ms, a)
            Hap.CLICK_UP -> pulse((ms / 2).coerceAtLeast(4), (a * 0.7f).toInt())
            Hap.TICK -> pulse((ms / 3).coerceAtLeast(3), (a * 0.6f).toInt())
            Hap.RIGHT, Hap.DRAG -> pulse(ms * 2, a)
            Hap.CONNECT, Hap.LOST -> pulse(ms * 4, a)
        }
    }
}
