package app.padlink

import android.annotation.SuppressLint
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothHidDevice
import android.bluetooth.BluetoothHidDeviceAppSdpSettings
import android.bluetooth.BluetoothManager
import android.bluetooth.BluetoothProfile
import android.content.Context
import java.util.concurrent.Executors

/**
 * Makes the phone show up as a Bluetooth mouse + keyboard (BluetoothHidDevice, Android 9+).
 * The computer needs no software at all, so this works with a Mac, a Windows PC, another Android
 * phone/tablet, a Chromebook, an iPad, a Linux box, a TV...
 */
@SuppressLint("MissingPermission")
class BtHidTransport(private val ctx: Context, cfg: Cfg) : Transport(cfg, 8000L) {
    override val label = "Bluetooth HID"

    private var hid: BluetoothHidDevice? = null
    private var host: BluetoothDevice? = null
    private val exec = Executors.newSingleThreadExecutor()

    private var btnMask = 0
    private var mods = 0
    private val pressed = LinkedHashSet<Int>()
    private var wheelRem = 0
    private var panRem = 0

    private val callback = object : BluetoothHidDevice.Callback() {
        override fun onAppStatusChanged(pluggedDevice: BluetoothDevice?, registered: Boolean) {
            if (!registered) {
                state(LinkState.ERROR, "Bluetooth HID app was unregistered")
                return
            }
            val h = hid
            if (pluggedDevice != null && h != null &&
                h.getConnectionState(pluggedDevice) == BluetoothProfile.STATE_CONNECTED
            ) {
                host = pluggedDevice
                state(LinkState.CONNECTED, pluggedDevice.name ?: pluggedDevice.address)
                return
            }
            state(LinkState.CONNECTING, "Ready. Pair and connect from your computer's Bluetooth settings.")
            val addr = Prefs.str("bt_addr", "")
            if (addr.isNotEmpty() && h != null) {
                try {
                    val mgr = ctx.getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager
                    h.connect(mgr.adapter.getRemoteDevice(addr))
                } catch (t: Throwable) {
                    log("auto-connect failed: ${t.message}")
                }
            }
        }

        override fun onConnectionStateChanged(device: BluetoothDevice?, connState: Int) {
            if (device == null) return
            if (connState == BluetoothProfile.STATE_CONNECTED) {
                host = device
                resetState()
                state(LinkState.CONNECTED, device.name ?: device.address)
            } else if (connState == BluetoothProfile.STATE_DISCONNECTED && host?.address == device.address) {
                host = null
                state(LinkState.LOST, "Computer disconnected")
            }
        }

        override fun onGetReport(device: BluetoothDevice?, type: Byte, id: Byte, bufferSize: Int) {
            if (device == null) return
            hid?.replyReport(device, type, id, ByteArray(if (id.toInt() == 2) 8 else 5))
        }

        override fun onSetReport(device: BluetoothDevice?, type: Byte, id: Byte, data: ByteArray?) {
            if (device != null) hid?.reportError(device, BluetoothHidDevice.ERROR_RSP_SUCCESS)
        }

        override fun onVirtualCableUnplug(device: BluetoothDevice?) {
            host = null
            state(LinkState.LOST, "Computer removed this device")
        }
    }

    override fun onStart() {
        val mgr = ctx.getSystemService(Context.BLUETOOTH_SERVICE) as? BluetoothManager
        val adapter = mgr?.adapter
        if (adapter == null || !adapter.isEnabled) {
            state(LinkState.ERROR, "Bluetooth is off")
            return
        }
        state(LinkState.CONNECTING, "Starting Bluetooth HID")
        val ok = adapter.getProfileProxy(ctx, object : BluetoothProfile.ServiceListener {
            override fun onServiceConnected(profile: Int, proxy: BluetoothProfile?) {
                if (profile != BluetoothProfile.HID_DEVICE || proxy == null) return
                val h = proxy as BluetoothHidDevice
                hid = h
                val sdp = BluetoothHidDeviceAppSdpSettings(
                    "PadLink", "Phone trackpad and keys", "PadLink",
                    BluetoothHidDevice.SUBCLASS1_COMBO, DESCRIPTOR
                )
                if (!h.registerApp(sdp, null, null, exec, callback)) {
                    state(LinkState.ERROR, "Bluetooth HID registration failed (another app may be using it)")
                }
            }

            override fun onServiceDisconnected(profile: Int) {
                hid = null
                state(LinkState.LOST, "Bluetooth service stopped")
            }
        }, BluetoothProfile.HID_DEVICE)
        if (!ok) state(LinkState.ERROR, "This phone does not offer the Bluetooth HID profile")
    }

    private fun resetState() {
        btnMask = 0; mods = 0; pressed.clear(); wheelRem = 0; panRem = 0
    }

    private fun report(id: Int, data: ByteArray) {
        val h = hid ?: return
        val d = host ?: return
        lagged {
            h.sendReport(d, id, data)
            sentPackets++
        }
        if (cfg.logPackets) log("report $id ${data.joinToString(" ") { (it.toInt() and 0xFF).toString(16) }}")
    }

    private fun mouse(dx: Int, dy: Int, wheel: Int, pan: Int) {
        report(1, byteArrayOf(btnMask.toByte(), dx.toByte(), dy.toByte(), wheel.toByte(), pan.toByte()))
    }

    private fun keyboard() {
        val b = ByteArray(8)
        b[0] = mods.toByte()
        var i = 2
        for (u in pressed) b[i++] = u.toByte()
        report(2, b)
    }

    override fun sendMove(dx: Int, dy: Int) {
        var x = dx
        var y = dy
        while (x != 0 || y != 0) {
            val cx = x.coerceIn(-127, 127)
            val cy = y.coerceIn(-127, 127)
            mouse(cx, cy, 0, 0)
            x -= cx
            y -= cy
        }
    }

    override fun sendScroll(sx: Int, sy: Int) {
        wheelRem += sy
        panRem += sx
        val w = wheelRem / 120
        val p = panRem / 120
        wheelRem -= w * 120
        panRem -= p * 120
        if (w != 0 || p != 0) mouse(0, 0, w.coerceIn(-127, 127), p.coerceIn(-127, 127))
    }

    override fun sendButton(b: Int, down: Boolean) {
        val bit = 1 shl b
        btnMask = if (down) btnMask or bit else btnMask and bit.inv()
        mouse(0, 0, 0, 0)
    }

    override fun sendKey(name: String, down: Boolean) {
        val m = HidKeys.modifier[name]
        if (m != null) {
            mods = if (down) mods or m else mods and m.inv()
        } else {
            val u = HidKeys.usage[name] ?: return
            if (down) {
                if (pressed.size < 6) pressed.add(u)
            } else {
                pressed.remove(u)
            }
        }
        keyboard()
    }

    override fun sendReleaseAll() {
        resetState()
        mouse(0, 0, 0, 0)
        keyboard()
    }

    override fun onClose() {
        try {
            if (host != null) sendReleaseAll()
            hid?.unregisterApp()
            val mgr = ctx.getSystemService(Context.BLUETOOTH_SERVICE) as? BluetoothManager
            mgr?.adapter?.closeProfileProxy(BluetoothProfile.HID_DEVICE, hid)
        } catch (_: Throwable) {
        }
        hid = null
        host = null
        exec.shutdown()
    }

    companion object {
        /** Composite HID descriptor: report 1 = mouse (5 buttons, X, Y, wheel, AC pan), report 2 = keyboard. */
        private val DESCRIPTOR: ByteArray = intArrayOf(
            // ---- mouse ----
            0x05, 0x01, 0x09, 0x02, 0xA1, 0x01, 0x85, 0x01, 0x09, 0x01, 0xA1, 0x00,
            0x05, 0x09, 0x19, 0x01, 0x29, 0x05, 0x15, 0x00, 0x25, 0x01, 0x95, 0x05, 0x75, 0x01, 0x81, 0x02,
            0x95, 0x01, 0x75, 0x03, 0x81, 0x03,
            0x05, 0x01, 0x09, 0x30, 0x09, 0x31, 0x09, 0x38, 0x15, 0x81, 0x25, 0x7F, 0x75, 0x08, 0x95, 0x03, 0x81, 0x06,
            0x05, 0x0C, 0x0A, 0x38, 0x02, 0x15, 0x81, 0x25, 0x7F, 0x75, 0x08, 0x95, 0x01, 0x81, 0x06,
            0xC0, 0xC0,
            // ---- keyboard ----
            0x05, 0x01, 0x09, 0x06, 0xA1, 0x01, 0x85, 0x02,
            0x05, 0x07, 0x19, 0xE0, 0x29, 0xE7, 0x15, 0x00, 0x25, 0x01, 0x75, 0x01, 0x95, 0x08, 0x81, 0x02,
            0x95, 0x01, 0x75, 0x08, 0x81, 0x01,
            0x95, 0x06, 0x75, 0x08, 0x15, 0x00, 0x25, 0x65, 0x05, 0x07, 0x19, 0x00, 0x29, 0x65, 0x81, 0x00,
            0xC0
        ).map { it.toByte() }.toByteArray()
    }
}
