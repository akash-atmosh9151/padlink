package app.padlink

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.graphics.Rect
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.net.wifi.WifiManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.Gravity
import android.view.KeyEvent
import android.view.Surface
import android.view.View
import android.view.ViewGroup
import android.view.WindowInsets
import android.view.WindowInsetsController
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

/** The play screen: [stick] [trackpad] [buttons], a thin status bar, and optional developer overlays. */
class PadActivity : Activity(), LinkListener, SensorEventListener {

    private lateinit var cfg: Cfg
    private lateinit var tr: Transport
    private lateinit var hap: Haptics
    private var buttons: ButtonsView? = null
    private var gamepad: GamepadView? = null
    private lateinit var status: TextView
    private lateinit var hud: TextView
    private lateinit var logView: TextView

    private val ui = Handler(Looper.getMainLooper())
    private var wifiLock: WifiManager.WifiLock? = null

    @Volatile private var state = LinkState.CONNECTING
    @Volatile private var message = ""
    private var hostName = ""

    private var inSettings = false
    private var backAt = 0L

    // developer HUD
    private var lastSent = 0L
    private var lastSampleT = 0L
    private var pps = 0
    private val logLines = ArrayDeque<String>()

    // gyro aiming
    @Volatile private var gyroHeld = false
    private var lastGyroT = 0L
    private var remGX = 0f
    private var remGY = 0f

    private val tick = object : Runnable {
        override fun run() {
            refresh()
            ui.postDelayed(this, 250)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Prefs.init(this)
        buildAll()
    }

    // ------------------------------------------------------------------ build

    private fun buildAll() {
        cfg = Cfg()
        hap = Haptics(this, cfg)
        tr = if (cfg.mode == "bt") BtHidTransport(this, cfg) else UdpTransport(cfg)
        tr.listener = this
        state = LinkState.CONNECTING
        message = ""
        if (cfg.keepAwake) window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        else window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        setContentView(buildUi())
        applyImmersive()
        if (cfg.mode == "wifi") acquireWifiLock()
        tr.start()
    }

    private fun rebuild() {
        if (::tr.isInitialized) {
            tr.listener = null
            tr.stop()
        }
        releaseWifiLock()
        buildAll()
    }

    private fun buildUi(): View {
        val m = Ui.dpi(this, 5)
        val root = FrameLayout(this)
        root.setBackgroundColor(Color.BLACK)
        root.setOnApplyWindowInsetsListener { v, ins -> applyInsets(v, ins) }
        root.addOnLayoutChangeListener { v, l, t, r, b, _, _, _, _ ->
            if (Build.VERSION.SDK_INT >= 29) v.systemGestureExclusionRects = listOf(Rect(0, 0, r - l, b - t))
        }

        if (cfg.layout == "controller") {
            val gp = GamepadView(this, cfg, tr, hap)
            hap.anchor = gp
            gamepad = gp
            root.addView(gp, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        } else {
        val pad = TrackpadView(this, cfg, tr, hap)
        hap.anchor = pad
        val game = cfg.layout == "game"
        val withButtons = cfg.layout != "pad"

        val tokens = ArrayList(cfg.keys)
        if (cfg.gyroMode == "hold" && !tokens.contains("gyro")) tokens.add("gyro")

        val stick: View? = if (game) StickView(this, cfg, tr, hap) else null
        val btns: ButtonsView? = if (withButtons) ButtonsView(this, cfg, tr, hap, tokens) else null
        btns?.onGyro = { held ->
            gyroHeld = held
            if (!held) lastGyroT = 0L
        }
        buttons = btns

        fun lp(weight: Float) = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, weight).apply {
            setMargins(m, m, m, m)
        }

        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        val left: View? = if (cfg.swapSides) btns else stick
        val right: View? = if (cfg.swapSides) stick else btns
        if (left != null) row.addView(left, lp(0.95f))
        row.addView(pad, lp(2.3f))
        if (right != null) row.addView(right, lp(0.95f))
        root.addView(row, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        }

        // status bar (top centre)
        val bar = LinearLayout(this)
        bar.orientation = LinearLayout.HORIZONTAL
        bar.gravity = Gravity.CENTER_VERTICAL
        bar.setBackgroundColor(0xCC000000.toInt())
        bar.setPadding(Ui.dpi(this, 10), Ui.dpi(this, 4), Ui.dpi(this, 4), Ui.dpi(this, 4))
        status = Ui.text(this, "", 11f, Color.WHITE, true)
        status.setOnClickListener { if (state != LinkState.CONNECTED) rebuild() }
        bar.addView(status)
        bar.addView(barButton("SET") {
            inSettings = true
            startActivity(Intent(this, SettingsActivity::class.java))
        })
        bar.addView(barButton("X") { finish() })
        root.addView(bar, FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT,
            Gravity.TOP or Gravity.CENTER_HORIZONTAL
        ))

        // developer overlays (touch-transparent)
        hud = Ui.text(this, "", 10f, Ui.OK, true)
        hud.setPadding(Ui.dpi(this, 10), Ui.dpi(this, 8), 0, 0)
        hud.visibility = if (cfg.hud) View.VISIBLE else View.GONE
        root.addView(hud, FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.TOP or Gravity.START
        ))
        logView = Ui.text(this, "", 9f, Ui.WARN, true)
        logView.setPadding(Ui.dpi(this, 10), 0, 0, Ui.dpi(this, 8))
        logView.visibility = if (cfg.logPackets) View.VISIBLE else View.GONE
        root.addView(logView, FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM or Gravity.START
        ))
        return root
    }

    private fun barButton(label: String, onClick: () -> Unit): TextView =
        Ui.text(this, label, 11f, Ui.DIM, true).apply {
            setPadding(Ui.dpi(this@PadActivity, 12), Ui.dpi(this@PadActivity, 6), Ui.dpi(this@PadActivity, 12), Ui.dpi(this@PadActivity, 6))
            isClickable = true
            setOnClickListener { onClick() }
        }

    @Suppress("DEPRECATION")
    private fun applyInsets(v: View, ins: WindowInsets): WindowInsets {
        if (Build.VERSION.SDK_INT >= 30) {
            val i = ins.getInsets(WindowInsets.Type.systemBars() or WindowInsets.Type.displayCutout())
            v.setPadding(i.left, i.top, i.right, i.bottom)
        } else {
            v.setPadding(ins.systemWindowInsetLeft, ins.systemWindowInsetTop, ins.systemWindowInsetRight, ins.systemWindowInsetBottom)
        }
        return ins
    }

    @Suppress("DEPRECATION")
    private fun applyImmersive() {
        if (!cfg.immersive) return
        if (Build.VERSION.SDK_INT >= 30) {
            window.insetsController?.let {
                it.hide(WindowInsets.Type.systemBars())
                it.systemBarsBehavior = WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            }
        } else {
            window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or
                View.SYSTEM_UI_FLAG_FULLSCREEN or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or
                View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
        }
    }

    // ------------------------------------------------------------------ link callbacks

    override fun onState(state: LinkState, detail: String) {
        runOnUiThread {
            this.state = state
            message = detail
            if (state == LinkState.CONNECTED && detail != "Link restored") hostName = detail
            when (state) {
                LinkState.CONNECTED -> hap.fire(Hap.CONNECT)
                LinkState.LOST, LinkState.ERROR -> hap.fire(Hap.LOST)
                else -> {}
            }
            refresh()
        }
    }

    override fun onHostHaptic(ms: Int, amp: Int) {
        if (cfg.hapHost) hap.pulse(ms, amp)
    }

    override fun onLog(line: String) {
        if (!cfg.logPackets) return
        synchronized(logLines) {
            logLines.addLast(line)
            while (logLines.size > 8) logLines.removeFirst()
        }
    }

    private fun refresh() {
        val now = SystemClock.elapsedRealtime()
        val sent = tr.sentPackets
        if (lastSampleT != 0L && now > lastSampleT) pps = ((sent - lastSent) * 1000 / (now - lastSampleT)).toInt()
        lastSent = sent
        lastSampleT = now

        val lat = tr.latencyMs
        val ping = if (lat >= 0) "  ${lat}ms" else ""
        when (state) {
            LinkState.CONNECTED -> { status.text = "● $hostName$ping"; status.setTextColor(Ui.OK) }
            LinkState.CONNECTING -> { status.text = "○ $message"; status.setTextColor(Ui.WARN) }
            LinkState.LOST -> { status.text = "● $message - tap to retry"; status.setTextColor(Ui.WARN) }
            LinkState.ERROR -> { status.text = "✕ $message - tap to retry"; status.setTextColor(Ui.ACCENT) }
            LinkState.CLOSED -> { status.text = "○ $message - tap to retry"; status.setTextColor(Ui.DIM) }
        }
        status.maxWidth = (resources.displayMetrics.widthPixels * 0.6f).toInt()

        if (cfg.hud) {
            hud.text = "LINK  ${tr.label}\n" +
                "STATE $state\n" +
                "RTT   ${if (lat >= 0) "$lat ms" else "-"}\n" +
                "OUT   $pps pkt/s   POLL ${if (cfg.pollHz == 0) "per event" else "${cfg.pollHz} Hz"}\n" +
                "LAG   +${cfg.fakeLag} ms (fake)\n" +
                "HAP   ${cfg.hapMode}  ${hap.describe()}"
        }
        if (cfg.logPackets) {
            synchronized(logLines) { logView.text = logLines.joinToString("\n") }
        }
    }

    // ------------------------------------------------------------------ gyro aiming

    override fun onSensorChanged(ev: SensorEvent) {
        if (ev.sensor.type != Sensor.TYPE_GYROSCOPE) return
        val active = cfg.gyroMode == "always" || (cfg.gyroMode == "hold" && gyroHeld)
        if (!active) { lastGyroT = 0L; return }
        if (lastGyroT == 0L) { lastGyroT = ev.timestamp; return }
        val dt = (ev.timestamp - lastGyroT) / 1_000_000_000f
        lastGyroT = ev.timestamp

        val gx = ev.values[0]
        val gy = ev.values[1]
        @Suppress("DEPRECATION")
        val rot = windowManager.defaultDisplay.rotation
        val up: Float
        val right: Float
        when (rot) {
            Surface.ROTATION_90 -> { up = gx; right = -gy }
            Surface.ROTATION_270 -> { up = -gx; right = gy }
            Surface.ROTATION_180 -> { up = -gy; right = -gx }
            else -> { up = gy; right = gx }
        }
        val k = dt * 900f * cfg.gyroSens
        var dx = -up * k
        var dy = right * k
        if (cfg.gyroInvX) dx = -dx
        if (cfg.gyroInvY) dy = -dy
        remGX += dx
        remGY += dy
        val ix = remGX.toInt()
        val iy = remGY.toInt()
        if (ix != 0 || iy != 0) {
            remGX -= ix; remGY -= iy
            tr.move(ix, iy)
        }
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}

    // ------------------------------------------------------------------ input extras

    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        if (cfg.volKeys && (keyCode == KeyEvent.KEYCODE_VOLUME_UP || keyCode == KeyEvent.KEYCODE_VOLUME_DOWN)) {
            if ((event?.repeatCount ?: 0) == 0) {
                tr.button(if (keyCode == KeyEvent.KEYCODE_VOLUME_UP) 0 else 1, true)
                hap.fire(Hap.CLICK_DOWN)
            }
            return true
        }
        return super.onKeyDown(keyCode, event)
    }

    override fun onKeyUp(keyCode: Int, event: KeyEvent?): Boolean {
        if (cfg.volKeys && (keyCode == KeyEvent.KEYCODE_VOLUME_UP || keyCode == KeyEvent.KEYCODE_VOLUME_DOWN)) {
            tr.button(if (keyCode == KeyEvent.KEYCODE_VOLUME_UP) 0 else 1, false)
            return true
        }
        return super.onKeyUp(keyCode, event)
    }

    @Suppress("DEPRECATION")
    override fun onBackPressed() {
        val now = SystemClock.elapsedRealtime()
        if (now - backAt < 1500) {
            super.onBackPressed()
        } else {
            backAt = now
            Toast.makeText(this, "Press back again to disconnect", Toast.LENGTH_SHORT).show()
        }
    }

    // ------------------------------------------------------------------ lifecycle

    override fun onResume() {
        super.onResume()
        if (inSettings) {
            inSettings = false
            rebuild()
        }
        applyImmersive()
        if (cfg.gyroMode != "off") {
            val sm = getSystemService(SENSOR_SERVICE) as SensorManager
            val g = sm.getDefaultSensor(Sensor.TYPE_GYROSCOPE)
            if (g != null) sm.registerListener(this, g, 5000)
            else Toast.makeText(this, "This phone has no gyroscope", Toast.LENGTH_SHORT).show()
        }
        ui.post(tick)
    }

    override fun onPause() {
        super.onPause()
        ui.removeCallbacks(tick)
        (getSystemService(SENSOR_SERVICE) as SensorManager).unregisterListener(this)
        gyroHeld = false
        lastGyroT = 0L
        buttons?.releaseAll()
        gamepad?.releaseAll()
        if (::tr.isInitialized) tr.releaseAll()
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) applyImmersive()
    }

    override fun onDestroy() {
        super.onDestroy()
        ui.removeCallbacks(tick)
        if (::tr.isInitialized) {
            tr.listener = null
            tr.stop()
        }
        releaseWifiLock()
    }

    // Keeps the Wi-Fi radio in its lowest-latency mode while playing.
    @Suppress("DEPRECATION")
    private fun acquireWifiLock() {
        try {
            val wm = applicationContext.getSystemService(WIFI_SERVICE) as WifiManager
            val mode = if (Build.VERSION.SDK_INT >= 29) WifiManager.WIFI_MODE_FULL_LOW_LATENCY
            else WifiManager.WIFI_MODE_FULL_HIGH_PERF
            wifiLock = wm.createWifiLock(mode, "padlink").also {
                it.setReferenceCounted(false)
                it.acquire()
            }
        } catch (_: Throwable) {
        }
    }

    private fun releaseWifiLock() {
        try { wifiLock?.let { if (it.isHeld) it.release() } } catch (_: Throwable) {}
        wifiLock = null
    }
}
