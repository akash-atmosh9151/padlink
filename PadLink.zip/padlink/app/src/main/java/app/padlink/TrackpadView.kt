package app.padlink

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.view.MotionEvent
import android.view.View
import kotlin.math.abs
import kotlin.math.hypot

/**
 * Multi-touch trackpad.
 *   1 finger          move pointer (speed-based acceleration)
 *   tap               left click
 *   tap, then hold    drag (left button held until you lift)
 *   2 fingers         scroll (natural or classic)
 *   2-finger tap      right click
 *   3-finger tap      middle click
 *
 * Motion is measured in dp, so the feel is the same on every phone. History samples are replayed so
 * the pointer follows the touch panel's real report rate, not the display refresh rate.
 */
class TrackpadView(
    ctx: Context,
    private val cfg: Cfg,
    private val tr: Transport,
    private val hap: Haptics
) : View(ctx) {

    private val density = ctx.resources.displayMetrics.density
    private val slopPx = cfg.tapSlopDp * density

    private var downTime = 0L
    private var maxPtrs = 0
    private var travel = 0f
    private var lastTapUp = 0L
    private var dragging = false

    private var havePrev = false
    private var prevX = 0f
    private var prevY = 0f
    private var prevT = 0L
    private var remX = 0f
    private var remY = 0f
    private var remSX = 0f
    private var remSY = 0f
    private var tickAcc = 0f
    private var cenX = 0f
    private var cenY = 0f

    // for drawing
    private var touching = false
    private var pCount = 0
    private val px = FloatArray(10)
    private val py = FloatArray(10)

    private val border = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = 2f * density }
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val label = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Ui.DIM; typeface = Ui.MONO; textSize = 13f * density; textAlign = Paint.Align.CENTER; letterSpacing = 0.3f
    }
    private val small = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Ui.DIM; typeface = Ui.MONO; textSize = 10f * density
    }

    init {
        setBackgroundColor(Ui.BG)
        isHapticFeedbackEnabled = true
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                requestUnbufferedDispatch(e)
                parent?.requestDisallowInterceptTouchEvent(true)
                downTime = e.eventTime
                maxPtrs = 1
                travel = 0f
                remX = 0f; remY = 0f; remSX = 0f; remSY = 0f; tickAcc = 0f
                touching = true
                if (cfg.tapDrag && lastTapUp != 0L && e.eventTime - lastTapUp < cfg.dragWindowMs) {
                    dragging = true
                    tr.button(0, true)
                    hap.fire(Hap.DRAG)
                }
                lastTapUp = 0L
                baseline(e, -1)
            }
            MotionEvent.ACTION_POINTER_DOWN -> {
                maxPtrs = maxOf(maxPtrs, e.pointerCount)
                baseline(e, -1)
            }
            MotionEvent.ACTION_POINTER_UP -> baseline(e, e.actionIndex)
            MotionEvent.ACTION_MOVE -> {
                val n = e.pointerCount
                for (h in 0 until e.historySize) {
                    centroid(e, h, -1)
                    sample(e.getHistoricalEventTime(h), cenX, cenY, n)
                }
                centroid(e, -1, -1)
                sample(e.eventTime, cenX, cenY, n)
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> finish(e)
        }
        // keep pointer positions for drawing
        pCount = if (e.actionMasked == MotionEvent.ACTION_UP || e.actionMasked == MotionEvent.ACTION_CANCEL) 0
        else minOf(e.pointerCount, 10)
        for (i in 0 until pCount) { px[i] = e.getX(i); py[i] = e.getY(i) }
        invalidate()
        return true
    }

    /** Average position of all pointers (optionally ignoring one that is being lifted). h = history index or -1. */
    private fun centroid(e: MotionEvent, h: Int, skip: Int) {
        var sx = 0f
        var sy = 0f
        var n = 0
        for (i in 0 until e.pointerCount) {
            if (i == skip) continue
            if (h >= 0) { sx += e.getHistoricalX(i, h); sy += e.getHistoricalY(i, h) }
            else { sx += e.getX(i); sy += e.getY(i) }
            n++
        }
        if (n > 0) { cenX = sx / n; cenY = sy / n }
    }

    private fun baseline(e: MotionEvent, skip: Int) {
        centroid(e, -1, skip)
        prevX = cenX; prevY = cenY; prevT = e.eventTime
        havePrev = true
    }

    private fun sample(t: Long, x: Float, y: Float, n: Int) {
        if (!havePrev) { prevX = x; prevY = y; prevT = t; havePrev = true; return }
        val dx = x - prevX
        val dy = y - prevY
        val dist = hypot(dx, dy)
        if (dist < cfg.deadzone) return
        val dt = (t - prevT).coerceAtLeast(1L)
        prevX = x; prevY = y; prevT = t
        travel += dist
        when (n) {
            1 -> pointer(dx / density, dy / density, dt)
            2 -> scroll(dx / density, dy / density)
        }
    }

    private fun pointer(dxDp: Float, dyDp: Float, dt: Long) {
        val speed = hypot(dxDp, dyDp) / dt                       // dp per ms
        val gain = cfg.sens * 3f * (1f + cfg.accel * minOf(speed * 2f, 3f))
        remX += dxDp * gain * (if (cfg.invertX) -1f else 1f)
        remY += dyDp * gain * (if (cfg.invertY) -1f else 1f)
        val ix = remX.toInt()
        val iy = remY.toInt()
        if (ix != 0 || iy != 0) {
            remX -= ix; remY -= iy
            tr.move(ix, iy)
        }
    }

    private fun scroll(dxDp: Float, dyDp: Float) {
        val u = 5f * cfg.scrollSpeed                              // 120 wheel units per ~24dp
        val sv = (if (cfg.naturalScroll) dyDp else -dyDp) * u
        val sh = (if (cfg.naturalScroll) -dxDp else dxDp) * u
        remSX += sh; remSY += sv
        val ix = remSX.toInt()
        val iy = remSY.toInt()
        if (ix != 0 || iy != 0) {
            remSX -= ix; remSY -= iy
            tr.scroll(ix, iy)
        }
        val step = maxOf(8f, cfg.hapScrollPx)
        tickAcc += abs(dxDp) + abs(dyDp)
        if (tickAcc >= step) {
            tickAcc %= step
            hap.fire(Hap.TICK)
        }
    }

    private fun finish(e: MotionEvent) {
        val cancel = e.actionMasked == MotionEvent.ACTION_CANCEL
        val tap = !cancel && (e.eventTime - downTime) <= cfg.tapMs && travel <= slopPx
        if (dragging) {
            tr.button(0, false)
            hap.fire(Hap.CLICK_UP)
            dragging = false
        } else if (tap) {
            when (maxPtrs) {
                1 -> if (cfg.tapClick) { click(0, Hap.CLICK_DOWN); lastTapUp = e.eventTime }
                2 -> if (cfg.twoTapRight) click(1, Hap.RIGHT)
                else -> if (cfg.threeTapMiddle && maxPtrs >= 3) click(2, Hap.RIGHT)
            }
        }
        havePrev = false
        maxPtrs = 0
        touching = false
    }

    private fun click(button: Int, h: Hap) {
        tr.button(button, true)
        hap.fire(h)
        val hold = cfg.clickHoldMs.coerceAtLeast(0)
        if (hold == 0) tr.button(button, false)
        else postDelayed({ tr.button(button, false) }, hold.toLong())
    }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        val r = 22f * density
        border.color = if (dragging) Ui.ACCENT else Ui.LINE
        c.drawRoundRect(2f * density, 2f * density, w - 2f * density, h - 2f * density, r, r, border)
        if (!touching) c.drawText("TRACKPAD", w / 2f, h / 2f, label)
        for (i in 0 until pCount) {
            fill.color = if (dragging) Ui.ACCENT else 0x33FFFFFF
            c.drawCircle(px[i], py[i], 30f * density, fill)
            if (cfg.touches) {
                c.drawText("${px[i].toInt()},${py[i].toInt()}", px[i] + 34f * density, py[i] - 34f * density, small)
            }
        }
    }
}
