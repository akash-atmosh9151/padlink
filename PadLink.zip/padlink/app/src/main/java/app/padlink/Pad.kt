package app.padlink

/** Button bits shared by the on-screen gamepad and every transport. Triggers are analog (lt/rt), not bits. */
object Pad {
    const val A = 1
    const val B = 2
    const val X = 4
    const val Y = 8
    const val LB = 16
    const val RB = 32
    const val BACK = 64
    const val START = 128
    const val UP = 256
    const val DOWN = 512
    const val LEFT = 1024
    const val RIGHT = 2048
}

/** Immutable controller snapshot. Sticks are -127..127 (+y = down, +x = right); triggers are 0..255. */
class PadState(
    val buttons: Int, val lx: Int, val ly: Int, val rx: Int, val ry: Int, val lt: Int, val rt: Int
) {
    fun neutral() = buttons == 0 && lx == 0 && ly == 0 && rx == 0 && ry == 0 && lt == 0 && rt == 0

    fun same(o: PadState) = buttons == o.buttons && lx == o.lx && ly == o.ly && rx == o.rx &&
        ry == o.ry && lt == o.lt && rt == o.rt

    companion object {
        val NEUTRAL = PadState(0, 0, 0, 0, 0, 0, 0)
    }
}
