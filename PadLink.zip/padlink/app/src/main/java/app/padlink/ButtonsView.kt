package app.padlink

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.view.MotionEvent
import android.view.View

/**
 * Grid of hold-able buttons: keyboard keys, mouse buttons, and (optionally) big LMB/RMB fire buttons.
 * Every finger is tracked independently, so you can hold several at once.
 *
 * Tokens in the "keys" setting:
 *   w, shift, space, f5 ...   keyboard keys (see HidKeys)
 *   lmb rmb mmb mb4 mb5       mouse buttons
 *   ~ctrl                     a leading ~ makes the button a latching toggle
 *   gyro                      hold to enable gyro aiming (when gyro mode is "hold")
 */
class ButtonsView(
    ctx: Context,
    private val cfg: Cfg,
    private val tr: Transport,
    private val hap: Haptics,
    keyTokens: List<String>
) : View(ctx) {

    var onGyro: ((Boolean) -> Unit)? = null

    private class Btn(val label: String, val mouse: Int, val key: String?, val toggle: Boolean, val gyro: Boolean) {
        val rect = RectF()
        var ptr = -1
        var latched = false
        val on get() = ptr != -1 || latched
    }

    private val density = ctx.resources.displayMetrics.density
    private val keyBtns = ArrayList<Btn>()
    private val fireBtns = ArrayList<Btn>()

    private val boxPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val linePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = 2f * density; color = Ui.LINE }
    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        typeface = Ui.MONO; textAlign = Paint.Align.CENTER; letterSpacing = 0.1f
    }

    init {
        setBackgroundColor(Ui.BG)
        val mouseNames = mapOf("lmb" to 0, "rmb" to 1, "mmb" to 2, "mb4" to 3, "mb5" to 4)
        for (raw in keyTokens.take(10)) {
            val toggle = raw.startsWith("~")
            val t = raw.removePrefix("~")
            when {
                t == "gyro" -> keyBtns.add(Btn("GYRO", -1, null, false, true))
                mouseNames.containsKey(t) -> keyBtns.add(Btn(t.uppercase(), mouseNames.getValue(t), null, toggle, false))
                HidKeys.isKnown(t) -> keyBtns.add(Btn(HidKeys.label(t), -1, t, toggle, false))
            }
        }
        if (cfg.fireButtons) {
            fireBtns.add(Btn("LMB", 0, null, false, false))
            fireBtns.add(Btn("RMB", 1, null, false, false))
        }
    }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        val m = 6f * density
        val fireH = if (fireBtns.isEmpty()) 0f else h * 0.46f
        // key grid: 2 columns in the top region
        val rows = ((keyBtns.size + 1) / 2).coerceAtLeast(1)
        val gridH = h - fireH
        val cw = (w - m * 3f) / 2f
        val ch = ((gridH - m * (rows + 1)) / rows).coerceIn(32f * density, 64f * density)
        for ((i, b) in keyBtns.withIndex()) {
            val col = i % 2
            val row = i / 2
            val l = m + col * (cw + m)
            val t = m + row * (ch + m)
            b.rect.set(l, t, l + cw, t + ch)
        }
        if (fireBtns.isNotEmpty()) {
            val top = h - fireH + m
            val bh = fireH - m * 2f
            val bw = (w - m * 3f) / 2f
            for ((i, b) in fireBtns.withIndex()) {
                val l = m + i * (bw + m)
                b.rect.set(l, top, l + bw, top + bh)
            }
        }
    }

    private fun all(): List<Btn> = keyBtns + fireBtns

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN, MotionEvent.ACTION_POINTER_DOWN -> {
                requestUnbufferedDispatch(e)
                val i = e.actionIndex
                press(e.getPointerId(i), e.getX(i), e.getY(i))
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_POINTER_UP -> release(e.getPointerId(e.actionIndex))
            MotionEvent.ACTION_CANCEL -> releaseAll()
        }
        invalidate()
        return true
    }

    private fun press(id: Int, x: Float, y: Float) {
        val b = all().firstOrNull { it.ptr == -1 && it.rect.contains(x, y) } ?: return
        b.ptr = id
        if (b.toggle) {
            b.latched = !b.latched
            send(b, b.latched)
        } else {
            send(b, true)
        }
        hap.fire(if (b.mouse >= 0 || b.key != null) Hap.KEY else Hap.CLICK_DOWN)
    }

    private fun release(id: Int) {
        val b = all().firstOrNull { it.ptr == id } ?: return
        b.ptr = -1
        if (!b.toggle) {
            send(b, false)
            hap.fire(Hap.CLICK_UP)
        }
    }

    fun releaseAll() {
        for (b in all()) {
            if (b.ptr != -1 && !b.toggle) send(b, false)
            if (b.latched) send(b, false)
            b.ptr = -1
            b.latched = false
        }
        invalidate()
    }

    private fun send(b: Btn, down: Boolean) {
        when {
            b.gyro -> onGyro?.invoke(down)
            b.mouse >= 0 -> tr.button(b.mouse, down)
            b.key != null -> tr.key(b.key, down)
        }
    }

    override fun onDraw(c: Canvas) {
        val r = 14f * density
        for (b in all()) {
            val big = b.rect.height() > 70f * density
            boxPaint.color = if (b.on) Ui.ACCENT else Ui.PANEL
            c.drawRoundRect(b.rect, r, r, boxPaint)
            c.drawRoundRect(b.rect, r, r, linePaint)
            textPaint.color = if (b.on) 0xFF000000.toInt() else 0xFFFFFFFF.toInt()
            textPaint.textSize = (if (big) 15f else 12f) * density
            val y = b.rect.centerY() - (textPaint.descent() + textPaint.ascent()) / 2f
            c.drawText(b.label + if (b.toggle) "*" else "", b.rect.centerX(), y, textPaint)
        }
    }
}
