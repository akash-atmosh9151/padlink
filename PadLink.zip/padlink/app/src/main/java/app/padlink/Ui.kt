package app.padlink

import android.app.AlertDialog
import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.os.Build
import android.text.Editable
import android.text.InputType
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowInsets
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.Switch
import android.widget.TextView
import java.util.Locale

object Ui {
    val BG = Color.parseColor("#000000")
    val PANEL = Color.parseColor("#121212")
    val LINE = Color.parseColor("#2C2C2C")
    val DIM = Color.parseColor("#8C8C8C")
    val ACCENT = Color.parseColor("#FF2D2D")
    val OK = Color.parseColor("#3DFF7A")
    val WARN = Color.parseColor("#FFB020")
    val MONO: Typeface = Typeface.MONOSPACE

    fun dp(ctx: Context, v: Float): Float = v * ctx.resources.displayMetrics.density
    fun dpi(ctx: Context, v: Int): Int = (v * ctx.resources.displayMetrics.density).toInt()

    fun text(ctx: Context, s: String, sp: Float = 14f, color: Int = Color.WHITE, mono: Boolean = false): TextView =
        TextView(ctx).apply {
            text = s
            textSize = sp
            setTextColor(color)
            if (mono) typeface = MONO
        }

    /** Flat outlined button. */
    fun button(ctx: Context, s: String, filled: Boolean = false, onClick: () -> Unit): TextView =
        TextView(ctx).apply {
            text = s.uppercase()
            typeface = MONO
            textSize = 13f
            gravity = Gravity.CENTER
            letterSpacing = 0.08f
            setTextColor(if (filled) Color.BLACK else Color.WHITE)
            setBackgroundColor(if (filled) Color.WHITE else PANEL)
            setPadding(dpi(ctx, 16), dpi(ctx, 14), dpi(ctx, 16), dpi(ctx, 14))
            isClickable = true
            setOnClickListener { onClick() }
        }

    fun lp(w: Int = ViewGroup.LayoutParams.MATCH_PARENT, h: Int = ViewGroup.LayoutParams.WRAP_CONTENT, weight: Float = 0f) =
        LinearLayout.LayoutParams(w, h, weight)

    /** Keeps a screen's content clear of the status bar, nav bar and camera cutout (Android 15 draws edge to edge). */
    @Suppress("DEPRECATION")
    fun fitSystemBars(v: View) {
        v.setOnApplyWindowInsetsListener { view, ins ->
            if (Build.VERSION.SDK_INT >= 30) {
                val i = ins.getInsets(WindowInsets.Type.systemBars() or WindowInsets.Type.displayCutout())
                view.setPadding(i.left, i.top, i.right, i.bottom)
            } else {
                view.setPadding(ins.systemWindowInsetLeft, ins.systemWindowInsetTop, ins.systemWindowInsetRight, ins.systemWindowInsetBottom)
            }
            ins
        }
    }
}

/** Tiny settings DSL: every row reads/writes Prefs directly. */
class Form(private val ctx: Context, private val root: LinearLayout) {
    private fun pad() = Ui.dpi(ctx, 18)

    fun section(title: String) {
        root.addView(Ui.text(ctx, title.uppercase(), 12f, Ui.ACCENT, true).apply {
            letterSpacing = 0.18f
            setPadding(pad(), Ui.dpi(ctx, 28), pad(), Ui.dpi(ctx, 6))
        })
    }

    fun info(s: String) {
        root.addView(Ui.text(ctx, s, 12f, Ui.DIM).apply { setPadding(pad(), Ui.dpi(ctx, 4), pad(), Ui.dpi(ctx, 8)) })
    }

    private fun titleBlock(title: String, sub: String?): LinearLayout =
        LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            addView(Ui.text(ctx, title, 15f))
            if (sub != null) addView(Ui.text(ctx, sub, 12f, Ui.DIM))
        }

    private fun row(): LinearLayout = LinearLayout(ctx).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(pad(), Ui.dpi(ctx, 10), pad(), Ui.dpi(ctx, 10))
    }

    fun toggle(title: String, key: String, def: Boolean, sub: String? = null) {
        val r = row()
        r.orientation = LinearLayout.HORIZONTAL
        r.gravity = Gravity.CENTER_VERTICAL
        val sw = Switch(ctx).apply {
            isChecked = Prefs.bool(key, def)
            setOnCheckedChangeListener { _, on -> Prefs.putBool(key, on) }
        }
        r.addView(titleBlock(title, sub), Ui.lp(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        r.addView(sw)
        r.setOnClickListener { sw.toggle() }
        root.addView(r)
    }

    fun slider(title: String, key: String, lo: Float, hi: Float, step: Float, def: Float, unit: String = "", sub: String? = null) {
        val steps = Math.round((hi - lo) / step)
        val cur = Prefs.flt(key, def).coerceIn(lo, hi)
        fun fmt(v: Float): String =
            (if (step >= 1f) v.toInt().toString() else String.format(Locale.US, "%.2f", v)) + unit
        val value = Ui.text(ctx, fmt(cur), 14f, Color.WHITE, true)
        val r = row()
        val head = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL }
        head.addView(titleBlock(title, sub), Ui.lp(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        head.addView(value)
        val bar = SeekBar(ctx)
        bar.max = steps
        bar.progress = Math.round((cur - lo) / step)
        bar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, p: Int, fromUser: Boolean) {
                val v = lo + p * step
                value.text = fmt(v)
                if (fromUser) Prefs.putFlt(key, v)
            }

            override fun onStartTrackingTouch(sb: SeekBar?) {}
            override fun onStopTrackingTouch(sb: SeekBar?) {}
        })
        r.addView(head)
        r.addView(bar)
        root.addView(r)
    }

    fun choice(title: String, key: String, options: List<Pair<String, String>>, def: String, sub: String? = null) {
        val r = row()
        val valueView = Ui.text(ctx, "", 13f, Ui.ACCENT, true)
        fun labelFor(v: String) = options.firstOrNull { it.first == v }?.second ?: v
        valueView.text = labelFor(Prefs.str(key, def))
        val head = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        head.addView(titleBlock(title, sub), Ui.lp(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        head.addView(valueView)
        r.addView(head)
        r.setOnClickListener {
            val idx = options.indexOfFirst { it.first == Prefs.str(key, def) }.coerceAtLeast(0)
            AlertDialog.Builder(ctx)
                .setTitle(title)
                .setSingleChoiceItems(options.map { it.second }.toTypedArray(), idx) { d, which ->
                    Prefs.putStr(key, options[which].first)
                    valueView.text = options[which].second
                    d.dismiss()
                }
                .show()
        }
        root.addView(r)
    }

    fun text(title: String, key: String, def: String, hint: String = "", numeric: Boolean = false, sub: String? = null) {
        val r = row()
        r.addView(titleBlock(title, sub))
        val et = EditText(ctx).apply {
            setText(Prefs.str(key, def))
            this.hint = hint
            typeface = Ui.MONO
            textSize = 14f
            setSingleLine()
            inputType = if (numeric) InputType.TYPE_CLASS_NUMBER else InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
            addTextChangedListener(object : TextWatcher {
                override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
                override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {}
                override fun afterTextChanged(s: Editable?) { Prefs.putStr(key, s?.toString()?.trim() ?: "") }
            })
        }
        r.addView(et)
        root.addView(r)
    }

    fun action(title: String, sub: String? = null, onClick: () -> Unit) {
        val r = row()
        r.addView(titleBlock(title, sub))
        r.isClickable = true
        r.setOnClickListener { onClick() }
        root.addView(r)
    }

    fun divider() {
        root.addView(View(ctx).apply { setBackgroundColor(Ui.LINE) }, Ui.lp(ViewGroup.LayoutParams.MATCH_PARENT, 1))
    }
}
