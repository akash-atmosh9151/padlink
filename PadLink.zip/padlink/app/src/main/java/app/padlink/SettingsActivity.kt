package app.padlink

import android.app.Activity
import android.app.AlertDialog
import android.graphics.Color
import android.os.Bundle
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.ScrollView

class SettingsActivity : Activity() {

    private lateinit var content: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Prefs.init(this)
        val scroll = ScrollView(this)
        scroll.setBackgroundColor(Color.BLACK)
        Ui.fitSystemBars(scroll)
        content = LinearLayout(this)
        content.orientation = LinearLayout.VERTICAL
        scroll.addView(content)
        setContentView(scroll)
        build()
    }

    private fun build() {
        content.removeAllViews()
        val f = Form(this, content)
        val pad = Ui.dpi(this, 18)

        content.addView(Ui.text(this, "SETTINGS", 24f, Color.WHITE, true).apply {
            letterSpacing = 0.2f
            setPadding(pad, Ui.dpi(this@SettingsActivity, 30), pad, 0)
        })
        f.info("Changes apply when you return to the pad (the link reconnects).")

        // ---------------------------------------------------------------- pointer
        f.section("Pointer")
        f.slider("Sensitivity", "sens", 0.3f, 6f, 0.1f, 1.6f, "x", "Cursor distance per finger distance")
        f.slider("Acceleration", "accel", 0f, 2f, 0.05f, 0.6f, "", "0 = linear, higher = fast flicks travel further")
        f.toggle("Invert X", "invert_x", false)
        f.toggle("Invert Y", "invert_y", false)

        // ---------------------------------------------------------------- gestures
        f.section("Gestures")
        f.toggle("Tap to click", "tap_click", true, "One-finger tap = left click")
        f.toggle("Tap, then hold to drag", "tap_drag", true, "Tap and immediately touch again; lift to drop")
        f.toggle("Two-finger tap = right click", "two_tap_right", true)
        f.toggle("Three-finger tap = middle click", "three_tap_middle", true)
        f.toggle("Natural scrolling", "natural_scroll", true, "Content follows your fingers")
        f.slider("Scroll speed", "scroll_speed", 0.2f, 4f, 0.1f, 1f, "x")

        // ---------------------------------------------------------------- layout
        f.section("Layout")
        f.choice(
            "Screen layout", "layout",
            listOf("pad" to "Trackpad only", "buttons" to "Trackpad + buttons", "game" to "Stick + trackpad + buttons"),
            "game"
        )
        f.toggle("Swap sides", "swap_sides", false, "Mirror the layout for left-handed play")
        f.toggle("Big LMB / RMB buttons", "fire_buttons", true)
        f.text(
            "Buttons", "keys", "shift,space,ctrl,r,e,q", "shift,space,ctrl,r,e,q",
            sub = "Comma separated, up to 10. Keys: a-z 0-9 shift ctrl alt cmd space tab esc enter f1-f12 up down left right ... " +
                "Mouse: lmb rmb mmb mb4 mb5. Prefix ~ to latch (~ctrl). 'gyro' = hold to aim with gyro."
        )
        f.text("Stick keys", "stick_keys", "w,a,s,d", "up,left,down,right", sub = "Order: up, left, down, right")

        // ---------------------------------------------------------------- haptics
        f.section("Haptics")
        f.choice(
            "Mode", "hap_mode",
            listOf(
                "crisp" to "Crisp (phone's tuned primitives)",
                "system" to "System (lowest latency)",
                "custom" to "Custom pulses",
                "off" to "Off"
            ),
            "crisp",
            "Crisp falls back to standard effects if the motor can't do primitives"
        )
        f.slider("Strength", "hap_strength", 20f, 255f, 5f, 200f)
        f.slider("Custom pulse length", "hap_ms", 4f, 60f, 1f, 18f, " ms", "Custom mode only")
        f.toggle("Clicks", "hap_click", true)
        f.toggle("Scroll ticks", "hap_scroll", true)
        f.slider("Scroll tick spacing", "hap_scroll_px", 16f, 120f, 4f, 48f, " dp")
        f.toggle("Drag start / drop", "hap_drag", true)
        f.toggle("Key and button presses", "hap_keys", true)
        f.toggle("Connect / disconnect", "hap_conn", true)
        f.toggle("Let the PC trigger haptics", "hap_host", true, "Wi-Fi receiver can send buzz commands (rumble)")
        content.addView(testRow())

        // ---------------------------------------------------------------- developer
        f.section("Developer")
        f.choice(
            "Send rate", "poll_hz",
            listOf(
                "0" to "Every touch event", "125" to "125 Hz", "250" to "250 Hz",
                "500" to "500 Hz", "1000" to "1000 Hz"
            ),
            "250",
            "How often accumulated motion is flushed. Bluetooth is capped near 125 Hz by the link"
        )
        f.slider("Artificial lag", "fake_lag", 0f, 200f, 5f, 0f, " ms", "Delays every packet, to test how your game feels with latency")
        f.toggle("Show HUD", "hud", false, "Link state, round-trip time, packets/s, haptics support")
        f.toggle("Show touch overlay", "touches", false, "Finger circles and coordinates")
        f.toggle("Show packet log", "log_packets", false, "Last messages sent (slows things slightly)")
        f.toggle("Volume keys = mouse buttons", "vol_keys", false, "Volume up = left click, down = right click")
        f.toggle("Keep screen on", "keep_awake", true)
        f.toggle("Immersive full screen", "immersive", true)
        f.divider()
        f.slider("Tap max duration", "tap_ms", 80f, 400f, 10f, 200f, " ms")
        f.slider("Tap max movement", "tap_slop", 2f, 30f, 1f, 10f, " dp")
        f.slider("Drag window", "drag_window", 100f, 600f, 20f, 280f, " ms", "Time to touch again after a tap to start a drag")
        f.slider("Click hold time", "click_hold", 0f, 100f, 5f, 25f, " ms", "How long a tap keeps the button down; some games miss 0 ms clicks")
        f.slider("Pointer dead zone", "deadzone", 0f, 6f, 0.5f, 0f, " px", "Ignore finger jitter smaller than this")
        f.divider()
        f.choice(
            "Gyro aiming", "gyro_mode",
            listOf("off" to "Off", "hold" to "While holding GYRO button", "always" to "Always on"),
            "off",
            "Tilt the phone to move the pointer, on top of the trackpad"
        )
        f.slider("Gyro sensitivity", "gyro_sens", 0.2f, 4f, 0.1f, 1f, "x")
        f.toggle("Invert gyro X", "gyro_inv_x", false)
        f.toggle("Invert gyro Y", "gyro_inv_y", false)
        f.divider()
        val hw = Haptics(this, Cfg()).describe()
        f.info("Haptics hardware: $hw")
        f.action("Reset all settings", "Back to defaults (keeps nothing)") {
            AlertDialog.Builder(this)
                .setTitle("Reset all settings?")
                .setPositiveButton("Reset") { _, _ -> Prefs.clearAll(); build() }
                .setNegativeButton("Cancel", null)
                .show()
        }
        content.addView(android.view.View(this), Ui.lp(ViewGroup.LayoutParams.MATCH_PARENT, Ui.dpi(this, 40)))
    }

    private fun testRow(): LinearLayout {
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        val m = Ui.dpi(this, 18)
        row.setPadding(m, Ui.dpi(this, 6), m, Ui.dpi(this, 6))
        fun add(label: String, h: Hap?) {
            val b = Ui.button(this, label) {
                val cfg = Cfg()
                val hp = Haptics(this, cfg)
                hp.anchor = row
                if (h != null) hp.test(h) else hp.pulse(cfg.hapMs, cfg.hapStrength)
            }
            val p = Ui.lp(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            p.rightMargin = Ui.dpi(this, 4)
            row.addView(b, p)
        }
        add("Click", Hap.CLICK_DOWN)
        add("Tick", Hap.TICK)
        add("Thud", Hap.DRAG)
        add("Double", Hap.CONNECT)
        add("Raw", null)
        return row
    }
}
