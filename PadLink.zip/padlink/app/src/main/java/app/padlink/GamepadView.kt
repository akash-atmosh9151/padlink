package app.padlink

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.view.MotionEvent
import android.view.View
import kotlin.math.abs
import kotlin.math.hypot
import kotlin.math.min

/**
 * Full-screen classic controller: left stick, d-pad, A B X Y, right stick, LB RB LT RT, Back, Start.
 * Multi-touch; every control owns the finger that landed on it until that finger lifts.
 */
class GamepadView(
    ctx: Context,
    private val cfg: Cfg,
    private val tr: Transport,
    private val hap: Haptics
) : View(ctx) {

    private val d = ctx.resources.displayMetrics.density

    // live controller state
    private var buttons = 0
    private var lx = 0; private var ly = 0
    private var rx = 0; private var ry = 0
    private var lt = 0; private var rt = 0
    private var last = PadState.NEUTRAL

    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val line = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = 2f * d }
    private val txt = Paint(Paint.ANTI_ALIAS_FLAG).apply { typeface = Ui.MONO; textAlign = Paint.Align.CENTER; color = Ui.DIM }

    init { setBackgroundColor(Ui.BG) }

    private fun push() {
        val s = PadState(buttons, lx, ly, rx, ry, lt, rt)
        if (s.same(last)) return
        last = s
        tr.pad(s)
    }

    private fun setBit(bit: Int, on: Boolean) { buttons = if (on) buttons or bit else buttons and bit.inv() }

    // ------------------------------------------------------------------ controls

    private abstract inner class Ctl {
        var pid = -1
        abstract fun hit(x: Float, y: Float): Boolean
        open fun down(x: Float, y: Float) {}
        open fun move(x: Float, y: Float) {}
        open fun up() {}
        abstract fun draw(c: Canvas)
    }

    /** Round or rounded-rect push button. */
    private inner class Press(
        val label: String, val color: Int, val rect: RectF, val round: Boolean,
        val onChange: (Boolean) -> Unit
    ) : Ctl() {
        var on = false
        override fun hit(x: Float, y: Float): Boolean {
            val pad = if (round) rect.width() * 0.2f else 8f * d
            return x >= rect.left - pad && x <= rect.right + pad && y >= rect.top - pad && y <= rect.bottom + pad
        }
        override fun down(x: Float, y: Float) { on = true; onChange(true); hap.fire(Hap.KEY) }
        override fun up() { if (on) { on = false; onChange(false) } }
        override fun draw(c: Canvas) {
            fill.color = if (on) (color and 0x00FFFFFF) or 0xAA000000.toInt() else Ui.PANEL
            line.color = if (on) color else Ui.LINE
            if (round) {
                val r = rect.width() / 2f
                c.drawCircle(rect.centerX(), rect.centerY(), r, fill)
                c.drawCircle(rect.centerX(), rect.centerY(), r, line)
            } else {
                val r = min(rect.width(), rect.height()) * 0.3f
                c.drawRoundRect(rect, r, r, fill)
                c.drawRoundRect(rect, r, r, line)
            }
            txt.color = if (on) 0xFFFFFFFF.toInt() else (if (round) color else Ui.DIM)
            txt.textSize = (if (round) rect.width() * 0.42f else min(rect.height() * 0.38f, 15f * d))
            c.drawText(label, rect.centerX(), rect.centerY() + txt.textSize * 0.35f, txt)
        }
    }

    /** Fixed analog stick. */
    private inner class Stick(val cx: Float, val cy: Float, val r: Float, val onAxis: (Int, Int) -> Unit) : Ctl() {
        var kx = 0f; var ky = 0f
        override fun hit(x: Float, y: Float) = hypot(x - cx, y - cy) <= r * 1.5f
        override fun down(x: Float, y: Float) { move(x, y); hap.fire(Hap.KEY) }
        override fun move(x: Float, y: Float) {
            var dx = (x - cx) / r
            var dy = (y - cy) / r
            val m = hypot(dx, dy)
            if (m > 1f) { dx /= m; dy /= m }
            kx = dx; ky = dy
            val mm = hypot(dx, dy)
            val dz = 0.10f
            if (mm < dz) onAxis(0, 0)
            else {
                val k = (mm - dz) / (1f - dz) / mm
                onAxis((dx * k * 127f).toInt().coerceIn(-127, 127), (dy * k * 127f).toInt().coerceIn(-127, 127))
            }
        }
        override fun up() { kx = 0f; ky = 0f; onAxis(0, 0) }
        override fun draw(c: Canvas) {
            fill.color = Ui.PANEL
            line.color = Ui.LINE
            c.drawCircle(cx, cy, r, fill)
            c.drawCircle(cx, cy, r, line)
            val active = pid != -1
            fill.color = if (active) 0xAAFFFFFF.toInt() else 0x55FFFFFF
            c.drawCircle(cx + kx * r * 0.62f, cy + ky * r * 0.62f, r * 0.42f, fill)
        }
    }

    /** Four-way pad; sliding the thumb changes direction, diagonals are allowed. */
    private inner class DPad(val cx: Float, val cy: Float, val arm: Float) : Ctl() {
        var dirs = 0
        override fun hit(x: Float, y: Float) = hypot(x - cx, y - cy) <= arm * 1.7f
        override fun down(x: Float, y: Float) { move(x, y); hap.fire(Hap.KEY) }
        override fun move(x: Float, y: Float) {
            val dx = x - cx; val dy = y - cy
            var m = 0
            val t = arm * 0.35f
            if (dy < -t) m = m or Pad.UP
            if (dy > t) m = m or Pad.DOWN
            if (dx < -t) m = m or Pad.LEFT
            if (dx > t) m = m or Pad.RIGHT
            dirs = m
            buttons = (buttons and (Pad.UP or Pad.DOWN or Pad.LEFT or Pad.RIGHT).inv()) or m
        }
        override fun up() { dirs = 0; buttons = buttons and (Pad.UP or Pad.DOWN or Pad.LEFT or Pad.RIGHT).inv() }
        override fun draw(c: Canvas) {
            val w = arm * 0.62f
            fun cell(l: Float, t: Float, rr: Float, b: Float, on: Boolean) {
                fill.color = if (on) 0xAAFFFFFF.toInt() else Ui.PANEL
                line.color = Ui.LINE
                val rc = RectF(l, t, rr, b)
                c.drawRoundRect(rc, 8f * d, 8f * d, fill)
                c.drawRoundRect(rc, 8f * d, 8f * d, line)
            }
            cell(cx - w / 2, cy - arm, cx + w / 2, cy - w / 2, (dirs and Pad.UP) != 0)
            cell(cx - w / 2, cy + w / 2, cx + w / 2, cy + arm, (dirs and Pad.DOWN) != 0)
            cell(cx - arm, cy - w / 2, cx - w / 2, cy + w / 2, (dirs and Pad.LEFT) != 0)
            cell(cx + w / 2, cy - w / 2, cx + arm, cy + w / 2, (dirs and Pad.RIGHT) != 0)
            fill.color = Ui.PANEL
            c.drawRect(cx - w / 2, cy - w / 2, cx + w / 2, cy + w / 2, fill)
        }
    }

    private var ctls: List<Ctl> = emptyList()

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        super.onSizeChanged(w, h, ow, oh)
        val W = w.toFloat(); val H = h.toFloat()
        val flip = cfg.swapSides
        fun x(f: Float) = (if (flip) 1f - f else f) * W
        fun box(f0: Float, f1: Float, t: Float, b: Float): RectF {
            val a = x(f0); val c = x(f1)
            return RectF(min(a, c), t * H, kotlin.math.max(a, c), b * H)
        }
        fun circ(fx: Float, fy: Float, r: Float) = RectF(x(fx) - r, fy * H - r, x(fx) + r, fy * H + r)

        val green = 0xFF3DDC6E.toInt(); val red = 0xFFFF4D4D.toInt()
        val blue = 0xFF4DA3FF.toInt(); val yellow = 0xFFFFC53D.toInt()
        val fr = 0.105f * H
        val gap = 0.19f * H
        val abx = 0.86f; val aby = 0.44f

        val list = ArrayList<Ctl>()
        // sticks first so they win overlaps
        list += Stick(x(0.17f), 0.42f * H, 0.19f * H) { ax, ay -> lx = ax; ly = ay }
        list += Stick(x(0.66f), 0.73f * H, 0.16f * H) { ax, ay -> rx = ax; ry = ay }
        list += DPad(x(0.34f), 0.73f * H, 0.15f * H)
        // face buttons: Y top, A bottom, X left, B right
        list += Press("Y", yellow, circ(abx, aby, fr).also { it.offset(0f, -gap) }, true) { setBit(Pad.Y, it) }
        list += Press("A", green, circ(abx, aby, fr).also { it.offset(0f, gap) }, true) { setBit(Pad.A, it) }
        list += Press("X", blue, circ(abx, aby, fr).also { it.offset(if (flip) gap else -gap, 0f) }, true) { setBit(Pad.X, it) }
        list += Press("B", red, circ(abx, aby, fr).also { it.offset(if (flip) -gap else gap, 0f) }, true) { setBit(Pad.B, it) }
        // shoulders / triggers
        list += Press("LT", Ui.DIM, box(0.03f, 0.145f, 0.04f, 0.17f), false) { lt = if (it) 255 else 0 }
        list += Press("LB", Ui.DIM, box(0.155f, 0.27f, 0.04f, 0.17f), false) { setBit(Pad.LB, it) }
        list += Press("RB", Ui.DIM, box(0.73f, 0.845f, 0.04f, 0.17f), false) { setBit(Pad.RB, it) }
        list += Press("RT", Ui.DIM, box(0.855f, 0.97f, 0.04f, 0.17f), false) { rt = if (it) 255 else 0 }
        // centre
        list += Press("BACK", Ui.DIM, box(0.405f, 0.495f, 0.36f, 0.47f), false) { setBit(Pad.BACK, it) }
        list += Press("START", Ui.DIM, box(0.505f, 0.595f, 0.36f, 0.47f), false) { setBit(Pad.START, it) }
        ctls = list
    }

    // ------------------------------------------------------------------ touch

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN, MotionEvent.ACTION_POINTER_DOWN -> {
                requestUnbufferedDispatch(e)
                val i = e.actionIndex
                val id = e.getPointerId(i)
                val x = e.getX(i); val y = e.getY(i)
                val c = ctls.firstOrNull { it.pid == -1 && it.hit(x, y) }
                if (c != null) { c.pid = id; c.down(x, y) }
            }
            MotionEvent.ACTION_MOVE -> for (c in ctls) if (c.pid != -1) {
                val i = e.findPointerIndex(c.pid)
                if (i >= 0) c.move(e.getX(i), e.getY(i))
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_POINTER_UP -> {
                val id = e.getPointerId(e.actionIndex)
                ctls.firstOrNull { it.pid == id }?.let { it.pid = -1; it.up() }
                if (e.actionMasked == MotionEvent.ACTION_UP) releaseAll()
            }
            MotionEvent.ACTION_CANCEL -> releaseAll()
        }
        push()
        invalidate()
        return true
    }

    fun releaseAll() {
        for (c in ctls) { c.pid = -1; c.up() }
        buttons = 0; lx = 0; ly = 0; rx = 0; ry = 0; lt = 0; rt = 0
        push()
        invalidate()
    }

    override fun onDraw(c: Canvas) {
        for (ctl in ctls) ctl.draw(c)
    }
}
