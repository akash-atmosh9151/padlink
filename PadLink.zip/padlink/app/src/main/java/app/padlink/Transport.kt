package app.padlink

import java.util.concurrent.Executors
import java.util.concurrent.ScheduledExecutorService
import java.util.concurrent.TimeUnit

enum class LinkState { CONNECTING, CONNECTED, LOST, CLOSED, ERROR }

interface LinkListener {
    fun onState(state: LinkState, detail: String)
    fun onHostHaptic(ms: Int, amp: Int)
    fun onLog(line: String)
}

/**
 * Shared plumbing for every way of reaching a computer.
 *
 * Pointer motion and scroll are accumulated and flushed at the configured poll rate on a single
 * IO thread, so the touch thread never blocks on a socket. Buttons and keys flush pending motion
 * first, which keeps ordering correct (move, then click).
 *
 * Scroll unit: 120 = one wheel notch. +y = scroll up, +x = scroll right.
 * Buttons: 0 left, 1 right, 2 middle, 3 back, 4 forward.
 */
abstract class Transport(protected val cfg: Cfg, private val minIntervalUs: Long) {
    abstract val label: String

    @Volatile var latencyMs: Int = -1
    @Volatile var sentPackets: Long = 0
    @Volatile var listener: LinkListener? = null

    private val lock = Any()
    private var accX = 0
    private var accY = 0
    private var accSX = 0
    private var accSY = 0

    protected val io: ScheduledExecutorService = Executors.newSingleThreadScheduledExecutor()
    private val lagger: ScheduledExecutorService = Executors.newSingleThreadScheduledExecutor()
    @Volatile private var closed = false

    protected abstract fun onStart()
    protected abstract fun sendMove(dx: Int, dy: Int)
    protected abstract fun sendScroll(sx: Int, sy: Int)
    protected abstract fun sendButton(b: Int, down: Boolean)
    protected abstract fun sendKey(name: String, down: Boolean)
    protected abstract fun sendReleaseAll()
    protected abstract fun onClose()

    fun start() {
        if (cfg.layout == "controller") {
            io.scheduleAtFixedRate(Runnable { padTick() }, 0, 16, TimeUnit.MILLISECONDS)
        }
        if (cfg.pollHz > 0) {
            val us = maxOf(minIntervalUs, 1_000_000L / cfg.pollHz)
            io.scheduleAtFixedRate(Runnable { safeFlush() }, 0, us, TimeUnit.MICROSECONDS)
        }
        onStart()
    }

    fun move(dx: Int, dy: Int) {
        if (dx == 0 && dy == 0) return
        synchronized(lock) { accX += dx; accY += dy }
        if (cfg.pollHz == 0) post { safeFlush() }
    }

    fun scroll(sx: Int, sy: Int) {
        if (sx == 0 && sy == 0) return
        synchronized(lock) { accSX += sx; accSY += sy }
        if (cfg.pollHz == 0) post { safeFlush() }
    }

    fun button(b: Int, down: Boolean) = post { safeFlush(); sendButton(b, down) }
    fun key(name: String, down: Boolean) = post { safeFlush(); sendKey(name, down) }
    fun releaseAll() {
        padCur = PadState.NEUTRAL
        padRepeats = 10
        post { safeFlush(); emuClear(); sendReleaseAll() }
    }

    // ------------------------------------------------------------------ controller

    @Volatile private var padCur = PadState.NEUTRAL
    @Volatile private var padRepeats = 0

    /** New controller state from the on-screen gamepad (called on the UI thread, only when something changed). */
    fun pad(s: PadState) {
        padCur = s
        padRepeats = 10
        post { sendPad(padCur, false) }
    }

    // Re-sends the state at ~60 Hz while any input is held (and for a moment after release), so a lost
    // packet can never leave a key or axis stuck, and the right stick can drive the mouse smoothly.
    private fun padTick() {
        guard {
            val s = padCur
            if (!s.neutral()) sendPad(s, true)
            else if (padRepeats > 0) { padRepeats--; sendPad(s, true) }
        }
    }

    // Keyboard + mouse emulation of the controller (used for Wi-Fi, and Bluetooth when "keys" output is chosen).
    private val emuKeys = HashSet<String>()
    private val emuResend = HashMap<String, Int>()
    private var lookX = 0f
    private var lookY = 0f

    private fun emuPress(name: String, down: Boolean) {
        when (name) {
            "lmb" -> sendButton(0, down)
            "rmb" -> sendButton(1, down)
            "mmb" -> sendButton(2, down)
            else -> sendKey(name, down)
        }
    }

    private fun emuClear() {
        for (n in emuKeys) emuPress(n, false)
        emuKeys.clear(); emuResend.clear(); lookX = 0f; lookY = 0f
    }

    protected open fun sendPad(s: PadState, tick: Boolean) {
        val want = HashSet<String>()
        val k = cfg.padKeys
        val b = s.buttons
        if (b and Pad.A != 0) want.add(k[0])
        if (b and Pad.B != 0) want.add(k[1])
        if (b and Pad.X != 0) want.add(k[2])
        if (b and Pad.Y != 0) want.add(k[3])
        if (b and Pad.LB != 0) want.add(k[4])
        if (b and Pad.RB != 0) want.add(k[5])
        if (s.lt > 100) want.add(k[6])
        if (s.rt > 100) want.add(k[7])
        if (b and Pad.BACK != 0) want.add(k[8])
        if (b and Pad.START != 0) want.add(k[9])
        val sk = cfg.stickKeys                    // up, left, down, right
        val thr = 45
        if (s.ly < -thr) want.add(sk[0])
        if (s.lx < -thr) want.add(sk[1])
        if (s.ly > thr) want.add(sk[2])
        if (s.lx > thr) want.add(sk[3])
        if (b and Pad.UP != 0) want.add("up")
        if (b and Pad.LEFT != 0) want.add("left")
        if (b and Pad.DOWN != 0) want.add("down")
        if (b and Pad.RIGHT != 0) want.add("right")

        for (n in want) if (n !in emuKeys) { emuPress(n, true); emuResend.remove(n) }
        for (n in emuKeys.toList()) if (n !in want) { emuPress(n, false); emuResend[n] = 4 }
        emuKeys.clear(); emuKeys.addAll(want)

        if (tick) {
            for (n in emuResend.keys.toList()) {
                emuPress(n, false)
                val left = (emuResend[n] ?: 0) - 1
                if (left <= 0) emuResend.remove(n) else emuResend[n] = left
            }
            // right stick = mouse look
            val dz = 12
            val gain = 22f * cfg.padLook
            val fx = if (kotlin.math.abs(s.rx) > dz) Math.signum(s.rx.toFloat()) * (s.rx / 127f) * (s.rx / 127f) * gain else 0f
            val fy = if (kotlin.math.abs(s.ry) > dz) Math.signum(s.ry.toFloat()) * (s.ry / 127f) * (s.ry / 127f) * gain else 0f
            lookX += fx; lookY += fy
            val ix = lookX.toInt(); val iy = lookY.toInt()
            if (ix != 0 || iy != 0) { lookX -= ix; lookY -= iy; move(ix, iy) }
        }
    }

    fun stop() {
        if (closed) return
        closed = true
        try { io.execute { guard { onClose() } } } catch (_: Throwable) {}
        io.shutdown()
        lagger.shutdown()
    }

    /** Run a network write after the artificial delay set in developer options (0 = immediately). */
    protected fun lagged(r: () -> Unit) {
        val l = cfg.fakeLag
        if (l <= 0) r() else lagger.schedule(Runnable { guard(r) }, l.toLong(), TimeUnit.MILLISECONDS)
    }

    protected fun log(s: String) { listener?.onLog(s) }
    protected fun state(s: LinkState, detail: String = "") { listener?.onState(s, detail) }

    private fun post(r: () -> Unit) {
        try { io.execute { guard(r) } } catch (_: Throwable) {}
    }

    private fun guard(r: () -> Unit) {
        try { r() } catch (t: Throwable) { log("error: ${t.message}") }
    }

    private fun safeFlush() {
        guard {
            var dx = 0; var dy = 0; var sx = 0; var sy = 0
            synchronized(lock) {
                dx = accX; dy = accY; sx = accSX; sy = accSY
                accX = 0; accY = 0; accSX = 0; accSY = 0
            }
            if (dx != 0 || dy != 0) sendMove(dx, dy)
            if (sx != 0 || sy != 0) sendScroll(sx, sy)
        }
    }
}
