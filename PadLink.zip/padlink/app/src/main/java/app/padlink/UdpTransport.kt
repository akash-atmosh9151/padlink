package app.padlink

import android.os.Build
import android.os.SystemClock
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress
import java.net.SocketTimeoutException
import java.util.concurrent.TimeUnit
import kotlin.concurrent.thread

/**
 * Wi-Fi link to the PadLink receiver running on a Mac or Windows PC.
 *
 * Wire format (UTF-8, one message per UDP datagram, fields separated by spaces):
 *   phone -> PC   HELLO <pin|-> <device_name>           first packet, no token yet
 *   PC -> phone   OK <token> <os> <hostname...>   |   NO <reason>
 *   phone -> PC   <token> M dx dy                       relative pointer motion
 *                 <token> S sx sy                       scroll, 120 = one notch, +y up, +x right
 *                 <token> B <0..4> <0|1>                mouse button (left,right,middle,back,forward)
 *                 <token> K <name> <0|1>                key down/up (names from HidKeys)
 *                 <token> PING <ms>   /   REL   /   BYE
 *   PC -> phone   PONG <ms>   |   HAP <ms> <amp>   |   BYE
 *   discovery     phone broadcasts "PADLINK?"  ->  PC answers "PADLINK! <port> <os> <hostname...>"
 */
class UdpTransport(cfg: Cfg) : Transport(cfg, 1000L) {
    override val label = "Wi-Fi ${cfg.ip}:${cfg.port}"

    private var sock: DatagramSocket? = null
    private var addr: InetAddress? = null
    @Volatile private var token = ""
    @Volatile private var ready = false
    @Volatile private var dead = false
    @Volatile private var lostReported = false
    @Volatile private var lastPong = 0L

    override fun onStart() {
        thread(name = "padlink-connect", isDaemon = true) { connect() }
    }

    private fun connect() {
        state(LinkState.CONNECTING, "Reaching ${cfg.ip}")
        try {
            val a = InetAddress.getByName(cfg.ip)
            val s = DatagramSocket()
            s.soTimeout = 400
            try { s.trafficClass = 0x10 } catch (_: Throwable) {}
            addr = a
            sock = s

            val name = Build.MODEL.replace(' ', '_')
            val pin = if (cfg.pin.isEmpty()) "-" else cfg.pin
            val hello = "HELLO $pin $name".toByteArray()
            val buf = ByteArray(512)
            var hostName = cfg.ip

            for (i in 0 until 8) {
                if (dead) return
                s.send(DatagramPacket(hello, hello.size, a, cfg.port))
                try {
                    val p = DatagramPacket(buf, buf.size)
                    s.receive(p)
                    val msg = String(p.data, 0, p.length).trim()
                    if (msg.startsWith("OK ")) {
                        val parts = msg.split(' ', limit = 4)
                        token = parts.getOrNull(1) ?: ""
                        val os = parts.getOrNull(2) ?: "?"
                        hostName = (parts.getOrNull(3) ?: cfg.ip) + " ($os)"
                        break
                    }
                    if (msg.startsWith("NO")) {
                        state(LinkState.ERROR, "Receiver refused: ${msg.removePrefix("NO").trim()}")
                        return
                    }
                } catch (_: SocketTimeoutException) {
                }
            }
            if (token.isEmpty()) {
                state(LinkState.ERROR, "No answer from ${cfg.ip}:${cfg.port}. Is the receiver running, on the same Wi-Fi, and is the firewall open for UDP?")
                return
            }

            lastPong = SystemClock.elapsedRealtime()
            ready = true
            state(LinkState.CONNECTED, hostName)
            thread(name = "padlink-recv", isDaemon = true) { recvLoop(s) }
            io.scheduleAtFixedRate(Runnable { ping() }, 0, 1000, TimeUnit.MILLISECONDS)
        } catch (t: Throwable) {
            state(LinkState.ERROR, t.message ?: "Connection failed")
        }
    }

    private fun recvLoop(s: DatagramSocket) {
        val buf = ByteArray(512)
        while (!dead) {
            try {
                val p = DatagramPacket(buf, buf.size)
                s.receive(p)
                val parts = String(p.data, 0, p.length).trim().split(' ')
                when (parts[0]) {
                    "PONG" -> {
                        val t = parts.getOrNull(1)?.toLongOrNull()
                        val now = SystemClock.elapsedRealtime()
                        if (t != null) latencyMs = (now - t).toInt()
                        lastPong = now
                        if (lostReported) {
                            lostReported = false
                            state(LinkState.CONNECTED, "Link restored")
                        }
                    }
                    "HAP" -> listener?.onHostHaptic(
                        parts.getOrNull(1)?.toIntOrNull() ?: 30,
                        parts.getOrNull(2)?.toIntOrNull() ?: 200
                    )
                    "BYE" -> state(LinkState.CLOSED, "Receiver closed the link")
                }
            } catch (_: SocketTimeoutException) {
            } catch (t: Throwable) {
                if (!dead) log("recv stopped: ${t.message}")
                break
            }
        }
    }

    private fun ping() {
        if (!ready) return
        emit("PING ${SystemClock.elapsedRealtime()}")
        if (!lostReported && SystemClock.elapsedRealtime() - lastPong > 4000) {
            lostReported = true
            state(LinkState.LOST, "No reply from receiver")
        }
    }

    private fun emit(s: String) {
        val sk = sock ?: return
        val a = addr ?: return
        if (!ready) return
        val b = "$token $s".toByteArray()
        lagged {
            sk.send(DatagramPacket(b, b.size, a, cfg.port))
            sentPackets++
        }
        if (cfg.logPackets && !s.startsWith("PING")) log(s)
    }

    override fun sendMove(dx: Int, dy: Int) = emit("M $dx $dy")
    override fun sendScroll(sx: Int, sy: Int) = emit("S $sx $sy")
    override fun sendButton(b: Int, down: Boolean) = emit("B $b ${if (down) 1 else 0}")
    override fun sendKey(name: String, down: Boolean) = emit("K $name ${if (down) 1 else 0}")
    override fun sendReleaseAll() = emit("REL")

    override fun onClose() {
        try {
            val sk = sock
            val a = addr
            if (sk != null && a != null && ready) {
                val b = "$token BYE".toByteArray()
                sk.send(DatagramPacket(b, b.size, a, cfg.port))
            }
        } catch (_: Throwable) {
        }
        dead = true
        ready = false
        try { sock?.close() } catch (_: Throwable) {}
    }
}

data class Found(val ip: String, val port: Int, val os: String, val name: String)

/** Finds receivers on the local network by UDP broadcast. */
object Discovery {
    fun scan(port: Int, timeoutMs: Int, onFound: (Found) -> Unit) {
        thread(name = "padlink-scan", isDaemon = true) {
            try {
                val s = DatagramSocket()
                s.broadcast = true
                s.soTimeout = 250
                val msg = "PADLINK?".toByteArray()
                val end = SystemClock.elapsedRealtime() + timeoutMs
                val seen = HashSet<String>()
                val buf = ByteArray(512)
                var lastSend = 0L
                while (SystemClock.elapsedRealtime() < end) {
                    val now = SystemClock.elapsedRealtime()
                    if (now - lastSend > 700) {
                        lastSend = now
                        try {
                            s.send(DatagramPacket(msg, msg.size, InetAddress.getByName("255.255.255.255"), port))
                        } catch (_: Throwable) {
                        }
                    }
                    try {
                        val p = DatagramPacket(buf, buf.size)
                        s.receive(p)
                        val t = String(p.data, 0, p.length).trim()
                        if (t.startsWith("PADLINK!")) {
                            val ip = p.address.hostAddress
                            if (ip != null && seen.add(ip)) {
                                val parts = t.split(' ', limit = 4)
                                onFound(
                                    Found(
                                        ip,
                                        parts.getOrNull(1)?.toIntOrNull() ?: port,
                                        parts.getOrNull(2) ?: "?",
                                        parts.getOrNull(3) ?: ip
                                    )
                                )
                            }
                        }
                    } catch (_: SocketTimeoutException) {
                    }
                }
                s.close()
            } catch (_: Throwable) {
            }
        }
    }
}
