#!/usr/bin/env python3
"""
PadLink receiver for macOS and Windows.  No dependencies: just Python 3.8+.

    python3 padlink_host.py            # macOS
    py padlink_host.py                 # Windows

Then open PadLink on the phone, choose Wi-Fi, tap "Scan network" and Start.
(For Bluetooth mode you do not need this program at all.)

Console commands while it runs:   buzz [ms] [amp]   who   help   quit
Other programs can make the phone vibrate by sending the UDP text "HAP <ms> <amp>" to 127.0.0.1:<port+1>.
"""
import argparse
import platform
import random
import secrets
import select
import socket
import sys
import threading
import time

OS = {"Darwin": "macOS", "Windows": "Windows"}.get(platform.system(), platform.system())
HOST = socket.gethostname().replace(" ", "_")

# ----------------------------------------------------------------------------- backends


class Backend:
    """Tracks what is held so everything can be released if the phone vanishes."""

    def __init__(self, args):
        self.args = args
        self.buttons = set()
        self.keys = set()

    # subclasses implement the raw_* methods
    def move(self, dx, dy):
        self.raw_move(dx, dy)

    def scroll(self, sx, sy):
        self.raw_scroll(sx, sy)

    def button(self, b, down):
        if b not in (0, 1, 2, 3, 4):
            return
        if down:
            self.buttons.add(b)
        else:
            self.buttons.discard(b)
        self.raw_button(b, down)

    def key(self, name, down):
        if self.args.no_keys:
            return
        if down:
            self.keys.add(name)
        else:
            self.keys.discard(name)
        self.raw_key(name, down)

    def release_all(self):
        for b in list(self.buttons):
            try:
                self.button(b, False)
            except Exception as e:
                print("release error:", e)
        for k in list(self.keys):
            try:
                self.key(k, False)
            except Exception as e:
                print("release error:", e)


class DryBackend(Backend):
    def raw_move(self, dx, dy): print(f"move   {dx:+d} {dy:+d}")
    def raw_scroll(self, sx, sy): print(f"scroll {sx:+d} {sy:+d}")
    def raw_button(self, b, down): print(f"button {b} {'down' if down else 'up'}")
    def raw_key(self, name, down): print(f"key    {name} {'down' if down else 'up'}")


# ---- Windows: SendInput, using scancodes so DirectInput / raw-input games see the keys -----------

class WinBackend(Backend):
    def __init__(self, args):
        super().__init__(args)
        import ctypes
        from ctypes import wintypes
        self.ct = ctypes
        self.user32 = ctypes.windll.user32
        ULONG_PTR = ctypes.c_size_t

        class MOUSEINPUT(ctypes.Structure):
            _fields_ = [("dx", wintypes.LONG), ("dy", wintypes.LONG), ("mouseData", wintypes.DWORD),
                        ("dwFlags", wintypes.DWORD), ("time", wintypes.DWORD), ("dwExtraInfo", ULONG_PTR)]

        class KEYBDINPUT(ctypes.Structure):
            _fields_ = [("wVk", wintypes.WORD), ("wScan", wintypes.WORD), ("dwFlags", wintypes.DWORD),
                        ("time", wintypes.DWORD), ("dwExtraInfo", ULONG_PTR)]

        class HARDWAREINPUT(ctypes.Structure):
            _fields_ = [("uMsg", wintypes.DWORD), ("wParamL", wintypes.WORD), ("wParamH", wintypes.WORD)]

        class _U(ctypes.Union):
            _fields_ = [("mi", MOUSEINPUT), ("ki", KEYBDINPUT), ("hi", HARDWAREINPUT)]

        class INPUT(ctypes.Structure):
            _fields_ = [("type", wintypes.DWORD), ("u", _U)]

        self.INPUT, self.MI, self.KI = INPUT, MOUSEINPUT, KEYBDINPUT
        self.user32.SendInput.argtypes = [wintypes.UINT, ctypes.POINTER(INPUT), ctypes.c_int]
        self.sx = self.sy = 0.0
        vk = {}
        for c in "abcdefghijklmnopqrstuvwxyz":
            vk[c] = ord(c.upper())
        for c in "0123456789":
            vk[c] = ord(c)
        vk.update({
            "space": 0x20, "tab": 0x09, "enter": 0x0D, "esc": 0x1B, "backspace": 0x08, "caps": 0x14,
            "shift": 0x10, "ctrl": 0x11, "alt": 0x12, "cmd": 0x5B, "win": 0x5B, "gui": 0x5B,
            "insert": 0x2D, "delete": 0x2E, "home": 0x24, "end": 0x23, "pgup": 0x21, "pgdn": 0x22,
            "left": 0x25, "up": 0x26, "right": 0x27, "down": 0x28,
            "minus": 0xBD, "equals": 0xBB, "lbracket": 0xDB, "rbracket": 0xDD, "backslash": 0xDC,
            "semicolon": 0xBA, "quote": 0xDE, "grave": 0xC0, "comma": 0xBC, "period": 0xBE, "slash": 0xBF,
        })
        for i in range(1, 13):
            vk[f"f{i}"] = 0x6F + i
        self.vk = vk
        self.extended = {"insert", "delete", "home", "end", "pgup", "pgdn", "left", "up", "right", "down",
                         "cmd", "win", "gui"}

    def _mouse(self, dx=0, dy=0, data=0, flags=0):
        inp = self.INPUT(type=0)
        inp.u.mi = self.MI(dx, dy, data & 0xFFFFFFFF, flags, 0, 0)
        self.user32.SendInput(1, self.ct.byref(inp), self.ct.sizeof(self.INPUT))

    def raw_move(self, dx, dy):
        self._mouse(dx, dy, 0, 0x0001)

    def raw_scroll(self, sx, sy):
        s = self.args.scroll_scale
        self.sx += sx * s
        self.sy += sy * s
        ix, iy = int(self.sx), int(self.sy)
        self.sx -= ix
        self.sy -= iy
        if iy:
            self._mouse(0, 0, iy, 0x0800)
        if ix:
            self._mouse(0, 0, -ix if self.args.flip_hscroll else ix, 0x1000)

    def raw_button(self, b, down):
        table = {0: (0x0002, 0x0004, 0), 1: (0x0008, 0x0010, 0), 2: (0x0020, 0x0040, 0),
                 3: (0x0080, 0x0100, 1), 4: (0x0080, 0x0100, 2)}
        d, u, data = table[b]
        self._mouse(0, 0, data, d if down else u)

    def raw_key(self, name, down):
        vk = self.vk.get(name)
        if vk is None:
            return
        scan = self.user32.MapVirtualKeyW(vk, 0)
        flags = 0x0008  # KEYEVENTF_SCANCODE
        if name in self.extended:
            flags |= 0x0001
        if not down:
            flags |= 0x0002
        inp = self.INPUT(type=1)
        inp.u.ki = self.KI(0, scan, flags, 0, 0)
        self.user32.SendInput(1, self.ct.byref(inp), self.ct.sizeof(self.INPUT))


# ---- macOS: Quartz events through ctypes (needs Accessibility permission) ----------------------

class MacBackend(Backend):
    KEYS = {
        'a': 0, 's': 1, 'd': 2, 'f': 3, 'h': 4, 'g': 5, 'z': 6, 'x': 7, 'c': 8, 'v': 9, 'b': 11, 'q': 12,
        'w': 13, 'e': 14, 'r': 15, 'y': 16, 't': 17, '1': 18, '2': 19, '3': 20, '4': 21, '6': 22, '5': 23,
        'equals': 24, '9': 25, '7': 26, 'minus': 27, '8': 28, '0': 29, 'rbracket': 30, 'o': 31, 'u': 32,
        'lbracket': 33, 'i': 34, 'p': 35, 'enter': 36, 'l': 37, 'j': 38, 'quote': 39, 'k': 40,
        'semicolon': 41, 'backslash': 42, 'comma': 43, 'slash': 44, 'n': 45, 'm': 46, 'period': 47,
        'tab': 48, 'space': 49, 'grave': 50, 'backspace': 51, 'esc': 53, 'cmd': 55, 'win': 55, 'gui': 55,
        'shift': 56, 'caps': 57, 'alt': 58, 'ctrl': 59,
        'f1': 122, 'f2': 120, 'f3': 99, 'f4': 118, 'f5': 96, 'f6': 97, 'f7': 98, 'f8': 100, 'f9': 101,
        'f10': 109, 'f11': 103, 'f12': 111,
        'insert': 114, 'home': 115, 'pgup': 116, 'delete': 117, 'end': 119, 'pgdn': 121,
        'left': 123, 'right': 124, 'down': 125, 'up': 126,
    }
    MODS = {'shift': 0x20000, 'ctrl': 0x40000, 'alt': 0x80000, 'cmd': 0x100000, 'win': 0x100000,
            'gui': 0x100000, 'caps': 0x10000}

    def __init__(self, args):
        super().__init__(args)
        import ctypes
        import ctypes.util
        self.ct = ctypes
        c = ctypes
        self.cg = c.CDLL(ctypes.util.find_library("ApplicationServices")
                         or "/System/Library/Frameworks/ApplicationServices.framework/ApplicationServices")
        self.cf = c.CDLL(ctypes.util.find_library("CoreFoundation")
                         or "/System/Library/Frameworks/CoreFoundation.framework/CoreFoundation")

        class CGPoint(c.Structure):
            _fields_ = [("x", c.c_double), ("y", c.c_double)]

        class CGSize(c.Structure):
            _fields_ = [("w", c.c_double), ("h", c.c_double)]

        class CGRect(c.Structure):
            _fields_ = [("origin", CGPoint), ("size", CGSize)]

        self.CGPoint = CGPoint
        cg = self.cg
        cg.CGEventSourceCreate.restype = c.c_void_p
        cg.CGEventSourceCreate.argtypes = [c.c_int32]
        cg.CGEventCreate.restype = c.c_void_p
        cg.CGEventCreate.argtypes = [c.c_void_p]
        cg.CGEventGetLocation.restype = CGPoint
        cg.CGEventGetLocation.argtypes = [c.c_void_p]
        cg.CGEventCreateMouseEvent.restype = c.c_void_p
        cg.CGEventCreateMouseEvent.argtypes = [c.c_void_p, c.c_uint32, CGPoint, c.c_uint32]
        cg.CGEventCreateKeyboardEvent.restype = c.c_void_p
        cg.CGEventCreateKeyboardEvent.argtypes = [c.c_void_p, c.c_uint16, c.c_bool]
        cg.CGEventCreateScrollWheelEvent2.restype = c.c_void_p
        cg.CGEventCreateScrollWheelEvent2.argtypes = [c.c_void_p, c.c_uint32, c.c_uint32,
                                                      c.c_int32, c.c_int32, c.c_int32]
        cg.CGEventSetIntegerValueField.argtypes = [c.c_void_p, c.c_uint32, c.c_int64]
        cg.CGEventSetFlags.argtypes = [c.c_void_p, c.c_uint64]
        cg.CGEventPost.argtypes = [c.c_uint32, c.c_void_p]
        cg.CGGetActiveDisplayList.argtypes = [c.c_uint32, c.POINTER(c.c_uint32), c.POINTER(c.c_uint32)]
        cg.CGDisplayBounds.restype = CGRect
        cg.CGDisplayBounds.argtypes = [c.c_uint32]
        self.cf.CFRelease.argtypes = [c.c_void_p]
        try:
            cg.AXIsProcessTrusted.restype = c.c_bool
            if not cg.AXIsProcessTrusted():
                print("\n!! macOS has not allowed this program to control the computer.\n"
                      "   System Settings > Privacy & Security > Accessibility: enable your Terminal app,\n"
                      "   then restart this script.\n")
        except Exception:
            pass
        self.src = cg.CGEventSourceCreate(1)
        self.flags = 0
        self.sx = self.sy = 0.0
        self.bounds = None
        self.bounds_t = 0.0
        self.click_n = {}
        self.click_t = {}

    def _post(self, ev):
        self.cg.CGEventSetFlags(ev, self.flags)
        self.cg.CGEventPost(0, ev)  # kCGHIDEventTap
        self.cf.CFRelease(ev)

    def _loc(self):
        ev = self.cg.CGEventCreate(None)
        p = self.cg.CGEventGetLocation(ev)
        self.cf.CFRelease(ev)
        return p

    def _bounds(self):
        now = time.time()
        if self.bounds is None or now - self.bounds_t > 3.0:
            c = self.ct
            ids = (c.c_uint32 * 16)()
            n = c.c_uint32(0)
            self.cg.CGGetActiveDisplayList(16, ids, c.byref(n))
            x0 = y0 = 1e9
            x1 = y1 = -1e9
            for i in range(n.value):
                r = self.cg.CGDisplayBounds(ids[i])
                x0 = min(x0, r.origin.x)
                y0 = min(y0, r.origin.y)
                x1 = max(x1, r.origin.x + r.size.w - 1)
                y1 = max(y1, r.origin.y + r.size.h - 1)
            self.bounds = (x0, y0, x1, y1) if n.value else (0, 0, 1e5, 1e5)
            self.bounds_t = now
        return self.bounds

    def raw_move(self, dx, dy):
        p = self._loc()
        x0, y0, x1, y1 = self._bounds()
        x = min(max(p.x + dx, x0), x1)
        y = min(max(p.y + dy, y0), y1)
        if 0 in self.buttons:
            etype, btn = 6, 0      # left mouse dragged
        elif 1 in self.buttons:
            etype, btn = 7, 1      # right mouse dragged
        elif self.buttons:
            etype, btn = 27, 2     # other mouse dragged
        else:
            etype, btn = 5, 0      # mouse moved
        ev = self.cg.CGEventCreateMouseEvent(self.src, etype, self.CGPoint(x, y), btn)
        self.cg.CGEventSetIntegerValueField(ev, 4, int(dx))   # kCGMouseEventDeltaX
        self.cg.CGEventSetIntegerValueField(ev, 5, int(dy))   # kCGMouseEventDeltaY
        self._post(ev)

    def raw_scroll(self, sx, sy):
        s = self.args.scroll_scale
        self.sx += sx * s
        self.sy += sy * s
        ix, iy = int(self.sx), int(self.sy)
        self.sx -= ix
        self.sy -= iy
        if ix or iy:
            if self.args.flip_hscroll:
                ix = -ix
            ev = self.cg.CGEventCreateScrollWheelEvent2(self.src, 0, 2, iy, ix, 0)  # 0 = pixel units
            self._post(ev)

    def raw_button(self, b, down):
        p = self._loc()
        types = {0: (1, 2), 1: (3, 4)}.get(b, (25, 26))
        etype = types[0] if down else types[1]
        number = 0 if b == 0 else 1 if b == 1 else b  # middle=2, back=3, forward=4
        ev = self.cg.CGEventCreateMouseEvent(self.src, etype, p, number)
        if b >= 2:
            self.cg.CGEventSetIntegerValueField(ev, 3, number)        # kCGMouseEventButtonNumber
        if down:
            now = time.time()
            if now - self.click_t.get(b, 0) < 0.4:
                self.click_n[b] = self.click_n.get(b, 1) + 1
            else:
                self.click_n[b] = 1
            self.click_t[b] = now
        self.cg.CGEventSetIntegerValueField(ev, 1, self.click_n.get(b, 1))  # kCGMouseEventClickState
        self._post(ev)

    def raw_key(self, name, down):
        code = self.KEYS.get(name)
        if code is None:
            return
        mod = self.MODS.get(name)
        if mod is not None:
            self.flags = (self.flags | mod) if down else (self.flags & ~mod)
        ev = self.cg.CGEventCreateKeyboardEvent(self.src, code, bool(down))
        self._post(ev)


def make_backend(args):
    if args.dry_run:
        return DryBackend(args)
    if platform.system() == "Windows":
        return WinBackend(args)
    if platform.system() == "Darwin":
        return MacBackend(args)
    print("Only macOS and Windows are supported by this receiver (use --dry-run to test). "
          "On other systems use the app's Bluetooth mode.")
    sys.exit(1)


# ----------------------------------------------------------------------------- server

class Session:
    def __init__(self, addr, token, name):
        self.addr, self.token, self.name = addr, token, name
        self.last = time.time()
        self.idle = False


class Server:
    def __init__(self, args):
        self.args = args
        self.backend = make_backend(args)
        self.pin = "" if args.no_pin else (args.pin or f"{random.randint(0, 9999):04d}")
        self.sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        self.sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        self.sock.bind(("", args.port))
        self.local = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        self.local.bind(("127.0.0.1", args.port + 1))
        self.session = None
        self.fails = {}     # ip -> (count, window_start)
        self.running = True

    # -- helpers
    def send(self, text, addr):
        try:
            self.sock.sendto(text.encode(), addr)
        except OSError:
            pass

    def log(self, *a):
        if self.args.verbose:
            print(*a)

    def drop(self, why):
        if self.session:
            self.backend.release_all()
            print(f"- phone '{self.session.name}' disconnected ({why})")
            self.session = None

    # -- protocol
    def hello(self, parts, addr):
        ip = addr[0]
        count, since = self.fails.get(ip, (0, 0.0))
        now = time.time()
        if now - since > 60:
            count, since = 0, now
        if count >= 5:
            return                                       # temporarily ignore this address
        pin = parts[1] if len(parts) > 1 else "-"
        name = parts[2] if len(parts) > 2 else "phone"
        if self.pin and pin != self.pin:
            self.fails[ip] = (count + 1, since)
            self.send("NO bad-pin", addr)
            print(f"! refused {ip}: wrong PIN")
            return
        s = self.session
        if s and s.addr == addr:
            token = s.token                              # retry of a HELLO we already answered
            s.last = now
        else:
            if s:
                self.send("BYE", s.addr)
                self.drop("another phone connected")
            token = secrets.token_hex(4)
            self.session = Session(addr, token, name)
            print(f"+ phone '{name}' connected from {ip}")
        self.send(f"OK {token} {OS} {HOST}", addr)

    def handle(self, data, addr):
        parts = data.decode("utf-8", "ignore").split()
        if not parts:
            return
        head = parts[0]
        if head == "PADLINK?":
            self.send(f"PADLINK! {self.args.port} {OS} {HOST}", addr)
            return
        if head == "HELLO":
            self.hello(parts, addr)
            return
        s = self.session
        if s is None or head != s.token or addr != s.addr or len(parts) < 2:
            return
        s.last = time.time()
        s.idle = False
        cmd = parts[1]
        b = self.backend
        try:
            if cmd == "M":
                b.move(int(parts[2]), int(parts[3]))
            elif cmd == "S":
                b.scroll(int(parts[2]), int(parts[3]))
            elif cmd == "B":
                b.button(int(parts[2]), parts[3] == "1")
            elif cmd == "K":
                b.key(parts[2], parts[3] == "1")
            elif cmd == "PING":
                self.send(f"PONG {parts[2]}", addr)
            elif cmd == "REL":
                b.release_all()
            elif cmd == "BYE":
                self.drop("phone closed the link")
        except (ValueError, IndexError, KeyError) as e:
            self.log("bad packet", parts, e)

    def buzz(self, ms=30, amp=200):
        if self.session:
            self.send(f"HAP {int(ms)} {int(amp)}", self.session.addr)
            return True
        return False

    def tick(self):
        s = self.session
        if not s:
            return
        idle = time.time() - s.last
        if idle > 3 and not s.idle:
            s.idle = True
            self.backend.release_all()                   # never leave a key stuck down
            self.log("no packets for 3 s: released everything")
        if idle > 30:
            self.drop("timed out")

    # -- console
    def console(self):
        for line in sys.stdin:
            w = line.split()
            if not w:
                continue
            if w[0] == "buzz":
                ms = int(w[1]) if len(w) > 1 and w[1].isdigit() else 40
                amp = int(w[2]) if len(w) > 2 and w[2].isdigit() else 255
                print("sent" if self.buzz(ms, amp) else "no phone connected")
            elif w[0] == "who":
                s = self.session
                print(f"{s.name} @ {s.addr[0]}" if s else "nobody connected")
            elif w[0] in ("quit", "exit"):
                self.running = False
                return
            else:
                print("commands: buzz [ms] [amp] | who | quit")

    def run(self):
        print(f"\nPadLink receiver  ({OS}, {HOST})")
        print(f"  listening on UDP port {self.args.port}")
        print(f"  PIN: {self.pin or '(disabled)'}")
        ips = local_ips()
        print("  phone: PadLink > Wi-Fi > Scan network, or type one of: " + ", ".join(ips))
        if sys.stdin and sys.stdin.isatty():
            threading.Thread(target=self.console, daemon=True).start()
            print("  type 'buzz' to test haptics, 'quit' to exit")
        print("  Ctrl+C to stop\n")
        try:
            while self.running:
                r, _, _ = select.select([self.sock, self.local], [], [], 0.25)
                for s in r:
                    try:
                        data, addr = s.recvfrom(2048)
                    except OSError:
                        continue                          # Windows reports ICMP "port unreachable" here
                    if s is self.sock:
                        self.handle(data, addr)
                    else:
                        w = data.decode("utf-8", "ignore").split()
                        if w and w[0] == "HAP":
                            self.buzz(int(w[1]) if len(w) > 1 and w[1].isdigit() else 30,
                                      int(w[2]) if len(w) > 2 and w[2].isdigit() else 200)
                self.tick()
        except KeyboardInterrupt:
            pass
        finally:
            if self.session:
                self.send("BYE", self.session.addr)
            self.backend.release_all()
            print("\nstopped")


def local_ips():
    ips = []
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("10.255.255.255", 1))               # no packet is sent; just picks the LAN interface
        ips.append(s.getsockname()[0])
        s.close()
    except OSError:
        pass
    try:
        for ip in socket.gethostbyname_ex(socket.gethostname())[2]:
            if ip not in ips and not ip.startswith("127."):
                ips.append(ip)
    except OSError:
        pass
    return ips or ["(unknown)"]


def main():
    ap = argparse.ArgumentParser(description="PadLink receiver for macOS and Windows")
    ap.add_argument("--port", type=int, default=48915, help="UDP port (default 48915)")
    ap.add_argument("--pin", help="fixed PIN instead of a random one")
    ap.add_argument("--no-pin", action="store_true", help="do not require a PIN (trusted networks only)")
    ap.add_argument("--no-keys", action="store_true", help="ignore keyboard keys, pointer only")
    ap.add_argument("--scroll-scale", type=float, default=None,
                    help="scroll speed multiplier (default 1.0 on Windows, 0.35 on macOS)")
    ap.add_argument("--flip-hscroll", action="store_true", help="reverse horizontal scrolling")
    ap.add_argument("--dry-run", action="store_true", help="print actions instead of moving the mouse (testing)")
    ap.add_argument("-v", "--verbose", action="store_true")
    args = ap.parse_args()
    if args.scroll_scale is None:
        args.scroll_scale = 0.35 if platform.system() == "Darwin" else 1.0
    Server(args).run()


if __name__ == "__main__":
    main()
