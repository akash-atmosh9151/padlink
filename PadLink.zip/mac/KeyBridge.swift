// Reads lines like "d 49" (key down) / "u 49" (key up) from stdin
// and posts real macOS keyboard events.
import Foundation
import CoreGraphics

let src = CGEventSource(stateID: .hidSystemState)
while let line = readLine() {
    let p = line.split(separator: " ")
    guard p.count == 2, let k = UInt16(p[1]) else { continue }
    CGEvent(keyboardEventSource: src, virtualKey: k, keyDown: p[0] == "d")?
        .post(tap: .cghidEventTap)
}
