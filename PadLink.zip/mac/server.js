const http = require('http'), fs = require('fs'), path = require('path'), os = require('os');
const { spawn } = require('child_process');
const { WebSocketServer } = require('ws');

const PORT = process.env.PORT || 8080;
const PIN = process.env.PIN || String(Math.floor(1000 + Math.random() * 9000));
// Whitelist: browser key code -> macOS virtual keycode
const KEYS = { Space:49, KeyS:1, KeyA:0, KeyD:2, KeyQ:12, KeyE:14, KeyC:8, KeyV:9, Escape:53, Tab:48 };

const bin = path.join(__dirname, 'keybridge');
if (!fs.existsSync(bin)) { console.error('keybridge not built. Run: npm run build'); process.exit(1); }
const kb = spawn(bin, [], { stdio: ['pipe', 'inherit', 'inherit'] });
const down = new Map(); // code -> count of sockets holding it
function press(code, d) {
  if (!(code in KEYS)) return;
  kb.stdin.write((d ? 'd ' : 'u ') + KEYS[code] + '\n');
}

const page = fs.readFileSync(path.join(__dirname, 'public', 'index.html'));
const server = http.createServer((req, res) => {
  res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8', 'Cache-Control': 'no-store' });
  res.end(page);
});

const wss = new WebSocketServer({ server });
wss.on('connection', (ws, req) => {
  const pin = new URL(req.url, 'http://x').searchParams.get('pin');
  if (pin !== PIN) { ws.close(4001, 'bad pin'); return; }
  const mine = new Set();
  const set = (code, d) => {
    if (d && !mine.has(code)) { mine.add(code); press(code, true); }
    if (!d && mine.has(code)) { mine.delete(code); press(code, false); }
  };
  ws.on('message', m => {
    try { const { c, d } = JSON.parse(m); set(c, !!d); } catch {}
  });
  const releaseAll = () => [...mine].forEach(c => set(c, false));
  ws.on('close', releaseAll); // never leave a key stuck
  ws.on('error', releaseAll);
});

server.listen(PORT, '0.0.0.0', () => {
  const ip = Object.values(os.networkInterfaces()).flat().find(i => i.family === 'IPv4' && !i.internal);
  console.log('\n  PadLink running');
  console.log('  Open on your phone: http://' + (ip ? ip.address : 'YOUR-MAC-IP') + ':' + PORT);
  console.log('  PIN: ' + PIN + '\n');
});
process.on('exit', () => kb.kill());
